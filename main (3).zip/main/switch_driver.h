// /*
//  * SPDX-FileCopyrightText: 2021-2023 Espressif Systems (Shanghai) CO LTD
//  *
//  * SPDX-License-Identifier: LicenseRef-Included
//  *
//  * Redistribution and use in source and binary forms, with or without modification,
//  * are permitted provided that the following conditions are met:
//  *
//  * 1. Redistributions of source code must retain the above copyright notice,
//  *    this list of conditions and the following disclaimer.
//  *
//  * 2. Redistributions in binary form, except as embedded into a Espressif Systems
//  *    integrated circuit in a product or a software update for such product,
//  *    must reproduce the above copyright notice, this list of conditions and
//  *    the following disclaimer in the documentation and/or other materials
//  *    provided with the distribution.
//  *
//  * 3. Neither the name of the copyright holder nor the names of its contributors
//  *    may be used to endorse or promote products derived from this software without
//  *    specific prior written permission.
//  *
//  * 4. Any software provided in binary form under this license must not be reverse
//  *    engineered, decompiled, modified and/or disassembled.
//  *
//  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  * POSSIBILITY OF SUCH DAMAGE.
//  */
// #pragma once

// #include "driver/gpio.h"
// #include "app_nuos_timer.h"
// #include "freertos/FreeRTOS.h"
// #include "freertos/task.h"
// #include "freertos/timers.h"

// #ifdef __cplusplus
// extern "C" {
// #endif

// /* user should configure which I/O port as toggle switch input, default is GPIO9 */


// /* config button level depends on the pull up/down setting
//    push button level is on level = 1 when pull-down enable
//    push button level is on level = 0 when pull-up enable
// */
// #define GPIO_INPUT_LEVEL_ON             0
// #define GPIO_INPUT_LEVEL_OFF            1

// #define ESP_INTR_FLAG_DEFAULT           0

// #define PAIR_SIZE(TYPE_STR_PAIR) (sizeof(TYPE_STR_PAIR) / sizeof(TYPE_STR_PAIR[0]))

// typedef enum {
//     SWITCH_IDLE,
//     SWITCH_PRESS_ARMED,
//     SWITCH_PRESS_DETECTED,
//     SWITCH_PRESSED,
//     SWITCH_RELEASE_DETECTED,
//     SWITCH_LONG_PRESS_DETECTED,
//     SWITCH_DOUBLE_CLICK_DETECTED,
//     SWITCH_SINGLE_CLICK_DETECTED,
// } switch_state_t;

// typedef enum {
//     SWITCH_ON_CONTROL,
//     SWITCH_OFF_CONTROL,
//     SWITCH_ONOFF_TOGGLE_CONTROL,
//     SWITCH_LEVEL_UP_CONTROL,
//     SWITCH_LEVEL_DOWN_CONTROL,
//     SWITCH_LEVEL_CYCLE_CONTROL,
//     SWITCH_COLOR_CONTROL,
// } switch_func_t;


// #define BTN_EVT_SINGLE      (1U << 0)
// #define BTN_EVT_DOUBLE      (1U << 1)
// #define BTN_EVT_LONG        (1U << 2)
// #define BTN_EVT_MULTI       (1U << 3)
// #define BTN_EVT_COMBO_LONG  (1U << 4)


// #define SWITCH_ONOFF_TOGGLE_CONTROL    0x10
// #define SWITCH_DIMMING_CONTROL         0x11
// #define SWITCH_SCENE_CHANGE_CONTROL    0x12
// #define SWITCH_FACTORY_RESET_CONTROL   0x13
// #define SWITCH_NOTHING_CONTROL         0xFF

// typedef struct {
//     gpio_num_t pin;
//     uint8_t id;
//     switch_func_t func;
//     uint8_t keypressed;
//     uint32_t enabled_events;

//     uint8_t single_func;
//     uint8_t double_func;
//     uint8_t long_func;
//     uint8_t multi_func;
//     uint8_t combo_long_func;
// } switch_func_pair_t;


// // typedef struct {
// //     uint32_t pin;
// //     uint8_t id;
// //     switch_func_t func;
// //     uint8_t keypressed;
// // } switch_func_pair_t;

// typedef void (*esp_switch_callback_t)(switch_func_pair_t *param);

// /**
//  * @brief init function for switch and callback setup
//  *
//  * @param button_func_pair      pointer of the button pair.
//  * @param button_num            number of button pair.
//  * @param cb                    callback pointer.
//  */
// bool switch_driver_init(switch_func_pair_t *button_func_pair, uint8_t button_num, esp_switch_callback_t cb);
// #ifdef __cplusplus
// } // extern "C"
// #endif


#pragma once

#include "driver/gpio.h"
#include "app_nuos_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/timers.h"

#ifdef __cplusplus
extern "C" {
#endif

/* user should configure which I/O port as toggle switch input, default is GPIO9 */


/* config button level depends on the pull up/down setting
   push button level is on level = 1 when pull-down enable
   push button level is on level = 0 when pull-up enable
*/
#define GPIO_INPUT_LEVEL_ON             0
#define GPIO_INPUT_LEVEL_OFF            1

#define ESP_INTR_FLAG_DEFAULT           0

#define PAIR_SIZE(TYPE_STR_PAIR) (sizeof(TYPE_STR_PAIR) / sizeof(TYPE_STR_PAIR[0]))

typedef enum {
    SWITCH_IDLE,
    SWITCH_PRESS_ARMED,
    SWITCH_PRESS_DETECTED,
    SWITCH_PRESSED,
    SWITCH_RELEASE_DETECTED,
    SWITCH_LONG_PRESS_DETECTED,
    SWITCH_DOUBLE_CLICK_DETECTED,
    SWITCH_SINGLE_CLICK_DETECTED,
} switch_state_t;

typedef enum {
    SWITCH_ON_CONTROL,
    SWITCH_OFF_CONTROL,
    SWITCH_ONOFF_TOGGLE_CONTROL,
    SWITCH_LEVEL_UP_CONTROL,
    SWITCH_LEVEL_DOWN_CONTROL,
    SWITCH_LEVEL_CYCLE_CONTROL,
    SWITCH_COLOR_CONTROL,
} switch_func_t;


#define BTN_EVT_SINGLE      (1U << 0)
#define BTN_EVT_DOUBLE      (1U << 1)
#define BTN_EVT_LONG        (1U << 2)
#define BTN_EVT_MULTI       (1U << 3)
#define BTN_EVT_COMBO_LONG  (1U << 4)


#define SWITCH_ONOFF_TOGGLE_CONTROL    0x10
#define SWITCH_DIMMING_CONTROL         0x11
#define SWITCH_SCENE_CHANGE_CONTROL    0x12
#define SWITCH_FACTORY_RESET_CONTROL   0x13
#define SWITCH_NOTHING_CONTROL         0xFF

typedef struct {
    uint32_t pin;
    switch_func_t func;
    uint8_t keypressed;


    uint8_t id;
    uint32_t enabled_events;

    uint8_t single_func;
    uint8_t double_func;
    uint8_t long_func;
    uint8_t multi_func;
    uint8_t combo_long_func;

} switch_func_pair_t;

typedef void (*esp_switch_callback_t)(switch_func_pair_t *param);

/**
 * @brief init function for switch and callback setup
 *
 * @param button_func_pair      pointer of the button pair.
 * @param button_num            number of button pair.
 * @param cb                    callback pointer.
 */
bool switch_driver_init(switch_func_pair_t *button_func_pair, uint8_t button_num, esp_switch_callback_t cb);
#ifdef __cplusplus
} // extern "C"
#endif
