/*
 * webserver.c
 *
 *  Created on: 21-Feb-2024
 *      Author: procu
 */
#include "app_constants.h"
//#if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DMX || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_GROUP_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_IR_BLASTER || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_IR_BLASTER_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_SWITCH || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_GROUP_SWITCH || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_WIRELESS_REMOTE_SWITCH)
#ifdef USE_WIFI_WEBSERVER
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"


#include "esp_event.h"
#include "esp_log.h"
#ifndef USE_C3_ADAPTER_UART_HW
#include "esp_http_server.h"   /* Needed only for legacy local-HTTP builds */
#endif
// #include "esp_http_server.h"
#include "esp_wifi_webserver.h"
#include "cJSON.h"
#include "light_driver.h"
#include "app_nvs_store_info.h"
#include "app_hardware_driver.h"
#include "nvs_flash.h"
#include "ha/esp_zigbee_ha_standard.h"
#include "app_zigbee_scene_commands.h"
#include "app_zigbee_misc.h"
// #include "esp_wifi_station.h"

#ifdef USE_C3_ADAPTER_UART_HW
#include "zigbee_2_uart.h"
#endif
#define MAX_HTTP_RECV_BUFFER 			4096

static const char *TAG                  = "WEBSERVER";
#ifdef USE_C3_ADAPTER_UART_HW
extern void nuos_set_uart_link_fault(bool fault);
extern volatile TickType_t c6_last_uart_heartbeat;
extern volatile bool c6_uart_link_fault;
#endif
//extern wifi_info_handle_t wifi_info;
static int decode_type                  = 0;
bool state                              = false;
cJSON *ac_model                         = NULL;
cJSON *ac_index                         = NULL; 
cJSON *selected_items                   = NULL;
cJSON *option_selected                  = NULL;
cJSON *dbind                            = NULL;
cJSON *dstate                           = NULL;
cJSON *dlevel                           = NULL;
cJSON *dcolor                           = NULL;
cJSON *dcheck                           = NULL;
cJSON *offset_json                      = NULL;
cJSON *calibration_json                 = NULL;
cJSON *cobj_webserver                   = NULL;

#define JSON_QUEUE_SIZE                 10
#define JSON_MAX_LEN                    1048

typedef struct {
    char json[JSON_MAX_LEN];
    #if( USE_NUOS_ZB_DEVICE_TYPE != DEVICE_SCENE_DALI)
        TaskHandle_t http_task;   // task to notify when done
    #endif
} json_msg_t;

extern SemaphoreHandle_t recordsSemaphore;
json_msg_t msg;
QueueHandle_t json_queue;

#if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
    extern void process_dali_tasks(uint8_t index, uint8_t is_toggle, uint8_t is_scene);
#elif (USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH)
    extern void process_dali_tasks(uint8_t index, uint8_t is_toggle, uint8_t is_scene);     
#endif
uint8_t node_index, ep_index;
void remove_scene_task(void* args);

void remove_duplicates(int* array, int size, int* result, int* result_size);

char input_str[12];
const int size = MAX_DALI_ADDRESSES;//sizeof(dali_nvs_stt[0].device_ids) / sizeof(dali_nvs_stt[0].device_ids[0]);
// Allocate memory for the result arrays (same size as the original array)
int temp_result[MAX_DALI_ADDRESSES];
int temp_result_size;

int final_result[MAX_DALI_ADDRESSES];
int final_result_size;

uint8_t tmp_selected_ids[MAX_DALI_DEVICES_IN_SCENES] = {0};
const char resp1[] = "Post data received successfully";
const char resp2[] = "Error Getting Responses!!";

extern  void nuos_prepare_color_mode(uint8_t mode);
static TaskHandle_t dali_worker_task_handle = NULL;
static TaskHandle_t dali_group_worker_task_handle = NULL;
char * parse_query(const char *req_query);
char * parse_query_2(const char *req_query);
void parse_json_3(const char *json_str);
int map(int x, int in_min, int in_max, int out_min, int out_max) {
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}



void dali_group_state_worker_task(void *pvParameters) {
    bool dali_state = false;
    // If you need to pass variables like dali_id, handle them here
    uint8_t target_id = (uint32_t)pvParameters; 

    printf("DALI Worker Task Started for ID: %d\n", target_id);
    uint8_t cct = 0;
    TaskHandle_t l_task_handle;
    while (1) {
        // Place your continuous DALI execution code here
        // Example: query gear status, cycle colors, or dimming loops
        dali_state = !dali_state;

        nuos_dali_set_state_group(target_id, dali_state);
        // CRITICAL: Always include a delay to prevent watchdog timer resets
        vTaskDelay(pdMS_TO_TICKS(500)); 

        if(cct++ > 10){
            cct = 0;
            l_task_handle = dali_group_worker_task_handle;
            dali_group_worker_task_handle = NULL; // Reset handle pointer immediately
            vTaskDelete(l_task_handle);
        }

    }
}

void dali_state_worker_task(void *pvParameters) {
    bool dali_state = false;
    // If you need to pass variables like dali_id, handle them here
    uint8_t target_id = (uint32_t)pvParameters; 

    printf("DALI Worker Task Started for ID: %d\n", target_id);
    uint8_t cct = 0;
    TaskHandle_t l_task_handle;
    while (1) {
        // Place your continuous DALI execution code here
        // Example: query gear status, cycle colors, or dimming loops
        dali_state = !dali_state;

        nuos_dali_set_state(target_id, dali_state);
        // CRITICAL: Always include a delay to prevent watchdog timer resets
        vTaskDelay(pdMS_TO_TICKS(500)); 

        if(cct++ > 10){
            cct = 0;
            l_task_handle = dali_worker_task_handle;
            dali_worker_task_handle = NULL; // Reset handle pointer immediately
            vTaskDelete(l_task_handle);
        }
    }
}


/*
 * Send an asynchronous operation-completion frame to the C3.
 *
 * The C6 is the controller that actually performs fxn 73/74.  The C3
 * must NOT assume that receiving the original command means the operation
 * is complete.  It waits for this frame and then completes the HTTP request.
 */
static void send_uart_operation_complete(cJSON *request_root,
                                         int fxn,
                                         const char *operation,
                                         const char *status,
                                         int result)
{
    cJSON *response = cJSON_CreateObject();
    if (response == NULL) {
        ESP_LOGE(TAG, "Failed to create UART operation-complete JSON");
        return;
    }

    cJSON_AddNumberToObject(response, "fxn", fxn);
    cJSON_AddStringToObject(response, "type", "operation_complete");
    cJSON_AddStringToObject(response, "status", status ? status : "success");
    cJSON_AddStringToObject(response, "operation", operation ? operation : "unknown");
    cJSON_AddNumberToObject(response, "result", result);

    /*
     * Echo requestId when the C3 supplied one.  This lets the C3 match the
     * completion to the exact browser request when multiple operations are
     * introduced later.
     */
    cJSON *request_id = cJSON_GetObjectItem(request_root, "requestId");
    if (cJSON_IsString(request_id) && request_id->valuestring != NULL) {
        cJSON_AddStringToObject(response, "requestId", request_id->valuestring);
    }

    char *response_text = cJSON_PrintUnformatted(response);
    if (response_text != NULL) {
        //#if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI)
        send_serial(response_text);
        //#endif
        cJSON_free(response_text);
    }

    cJSON_Delete(response);
}

uint8_t dali_addresses[64] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63};
void parse_json(const char *json_string) {
    // Parse JSON string
    cJSON *root = cJSON_Parse(json_string);
    if (root == NULL) {
        printf("Error parsing JSON: %s\n", cJSON_GetErrorPtr());
        return;
    }
    wifi_webserver_active_counts = 0;
    // Extract values from JSON object
    cJSON *fxn = cJSON_GetObjectItem(root, "fxn");
    if (fxn == NULL){  
        // printf("------------ERROR returning back----------\n");  
        cJSON_Delete(root); 
        return;
    }
    recheckTimer();  

    int fxnInt = 0;
    if(cJSON_IsNumber(fxn)){
        fxnInt = fxn->valueint;    
    }else if(cJSON_IsString(fxn)) {
        if( fxn->valuestring != NULL){
            fxnInt = atoi(fxn->valuestring);
        }
    }
    //printf("Function: %d\n", fxnInt);
    /* UART link supervision frames are handled before normal application commands. */
    if (cJSON_IsNumber(fxn)) {
        int uart_fxn = fxn->valueint;
        #ifdef USE_C3_ADAPTER_UART_HW
        if (uart_fxn == 250) {
            c6_last_uart_heartbeat = xTaskGetTickCount();
            c6_uart_link_fault = false;
            nuos_set_uart_link_fault(false);
            cJSON *seq = cJSON_GetObjectItem(root, "seq");
            char ack[128];
            snprintf(ack, sizeof(ack),
                     "{\"fxn\":251,\"type\":\"uart_heartbeat_ack\",\"side\":\"C6\",\"seq\":%d}",
                     (seq && cJSON_IsNumber(seq)) ? seq->valueint : 0);
            #ifdef USE_C3_ADAPTER_UART_HW         
            send_serial(ack);
            #endif
            cJSON_Delete(root);
            return;
        }
        if (uart_fxn == 251) {
            c6_last_uart_heartbeat = xTaskGetTickCount();
            c6_uart_link_fault = false;
            nuos_set_uart_link_fault(false);
            cJSON_Delete(root);
            return;
        }
        if (uart_fxn == 252) {
            c6_uart_link_fault = true;
            nuos_set_uart_link_fault(true);
            ESP_LOGE(TAG, "C3 reports UART link fault");
            cJSON_Delete(root);
            return;
        }
        #endif
    }

    switch(fxnInt){ 
        case 14:
            wifi_webserver_active_flag = true;
            setNVSWebServerEnableFlag(true);
            esp_restart();
        break;

        case 13:
               
        case 4:  //cancel
            wifi_webserver_active_flag = false;
            light_driver_set_power(false);
            setNVSWebServerEnableFlag(false);
            esp_restart();
        break;
        case 73:
            /*
             * C6 performs the actual DALI factory reset.
             * Do NOT send completion before this function returns.
             */
            esp_dali_factory_reset_all_drivers();

            /* The C3/browser is waiting for this UART completion frame. */
            send_uart_operation_complete(root,
                                         73,
                                         "dali_factory_reset",
                                         "success",
                                         1);
        break;

        case 74:
            #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI)
            {
                cJSON *addressesJson = cJSON_GetObjectItem(root, "addresses");
                cJSON *numAddressesJson = cJSON_GetObjectItem(root, "numAddresses");

                if (!cJSON_IsNumber(addressesJson) || !cJSON_IsNumber(numAddressesJson)) {
                    ESP_LOGE(TAG, "fxn 74: missing/invalid addresses or numAddresses");
                    send_uart_operation_complete(root,
                                                 74,
                                                 "dali_addressing",
                                                 "error",
                                                 -1);
                    break;
                }

                uint8_t addresses = (uint8_t)addressesJson->valueint;
                uint8_t numAddresses = (uint8_t)numAddressesJson->valueint;

                ESP_LOGI(TAG,
                         "DALI ID addressing command: start address=%d, numAddresses=%d",
                         addresses,
                         numAddresses);

                /*
                 * This call does not return until the DALI addressing
                 * operation has completed.
                 */
                
                int assigned = esp_dali_init_nodes(&dali_addresses[addresses], numAddresses);

                ESP_LOGI(TAG,
                         "DALI ID addressing completed, assigned=%d",
                         assigned);

                send_uart_operation_complete(root,
                                             74,
                                             "dali_addressing",
                                             "success",
                                             assigned);
            }
            #else
                send_uart_operation_complete(root,
                                             74,
                                             "dali_addressing",
                                             "error",
                                             -1);
            #endif
        break;
        case 9:
        //"{\"fxn\": 9, \"webserver\": 0"
        cobj_webserver = cJSON_GetObjectItem(root, "webserver");
        if (cobj_webserver == NULL) {
            printf("Missing JSON keys\n");
            cJSON_Delete(root);
            return;
        }
        wifi_webserver_active_flag = (uint8_t)(cobj_webserver->valueint);
        if(wifi_webserver_active_flag == 0){
            printf("Stopping Web Server...\n"); 
            esp_stop_timer();
        }else{
            printf("Starting Web Server...\n");
            wifi_webserver_active_counts = 0;
            init_timer();
            esp_start_timer();
        }
        break;
        #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
            case 10:
                cJSON *sindex = cJSON_GetObjectItem(root, "index");
                if (sindex == NULL) {
                    printf("Missing JSON keys index\n");
                    cJSON_Delete(root);
                    return;
                } 

                int index = sindex->valueint;
                // printf("sindex: %d\n", index);
                // Get the values array
                cJSON *valuesArray = cJSON_GetObjectItem(root, "values");
                if (!cJSON_IsArray(valuesArray))
                {
                    ESP_LOGE(TAG, "Values is not an array");
                    cJSON_Delete(root);
                    return;
                }
                dali_nvs_stt[index].group_id = global_group_id[index];
                // Iterate over the array and print the values
                int arraySize = cJSON_GetArraySize(valuesArray);
                for (int i = 0; i < arraySize; ++i)
                {
                    cJSON *item = cJSON_GetArrayItem(valuesArray, i);
                    if (cJSON_IsNumber(item))
                    {
                        int value = item->valueint;
                        
                        temp_result[i] = value;

                        ESP_LOGI(TAG, "Value at index %d: %d", i, temp_result[i]);
                        
                    }
                }
                // Remove zeros
                int j = 0;
                for (int i = 0; i < size; ++i) {
                    if (temp_result[i] != 0) {
                        final_result[j++] = temp_result[i];
                    }
                }
                final_result_size = j;
                //remove 
                for (int i = 0; i < dali_nvs_stt[index].total_ids; ++i) {
                    nuos_dali_remove_light_from_group(dali_nvs_stt[index].device_ids[i], dali_nvs_stt[index].group_id);
                    vTaskDelay(20 / portTICK_PERIOD_MS);
                }
                // Remove duplicates
                j=0;
                for (int i = 0; i < final_result_size; ++i) {
                    bool is_duplicate = false;
                    for (int k = 0; k < j; ++k) {
                        if (dali_nvs_stt[index].device_ids[k] == final_result[i]) {
                            is_duplicate = true;
                            break;
                        }
                    }
                    if (!is_duplicate) {
                        dali_nvs_stt[index].device_ids[j++] = final_result[i];
                    }
                }
                dali_nvs_stt[index].total_ids = j;

                // Print the final result array
                printf("Array without zeros and duplicates: ");
                for (int i = 0; i < dali_nvs_stt[index].total_ids; ++i) {
                    printf("%d ", dali_nvs_stt[index].device_ids[i]);
                    nuos_dali_add_light_to_group(dali_nvs_stt[index].device_ids[i], dali_nvs_stt[index].group_id);
                    vTaskDelay(100 / portTICK_PERIOD_MS);
                }
                printf("\n");
                for (int p = dali_nvs_stt[index].total_ids; p < 20; p++) {
                    dali_nvs_stt[index].device_ids[p] = 0;
                }
                
                nuos_store_dali_data_to_nvs(index);
                break;
            #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI) 
            case 304:  //Toggle DALI ID
            // Track the active worker task instance
                uint8_t dali_id = 0xff;
                uint8_t group_id = 0xff;
                cJSON* sdali_id= cJSON_GetObjectItem(root, "dali_id");
                if (sdali_id == NULL) {
                    printf("Missing JSON keys dali_id\n");
                }   else{
                    dali_id = sdali_id->valueint;
                }

                cJSON* sgrp_id= cJSON_GetObjectItem(root, "group_id");
                if (sgrp_id == NULL) {
                    printf("Missing JSON keys group_id\n");
                    //cJSON_Delete(root);
                    //return;
                    
                }else{
                    group_id = sgrp_id->valueint;
                }
                
                
                printf("dali_id: %d\n", dali_id);
                printf("group_id: %d\n", group_id);

                cJSON*  sdali_state= cJSON_GetObjectItem(root, "state");
                if (sdali_state == NULL) {
                    printf("Missing JSON keys sdali_state\n");
                    cJSON_Delete(root);
                    return;
                }     
                uint8_t dali_state = sdali_state->valueint;
                printf("dali_state: %d\n", dali_state);
                if (dali_state == 1) {
                    // Only create the task if it isn't already running
                    
                    if(dali_id != 0xff){
                        if (dali_worker_task_handle == NULL) {
                            BaseType_t ret = xTaskCreate(
                                dali_state_worker_task,     // Task function
                                "dali_worker",             // Text name for debugging
                                4096,                      // Stack size in words
                                (void*)(uint32_t)dali_id,   // Pass dali_id as parameter
                                15,                         // Task priority
                                &dali_worker_task_handle   // Save the handle
                            );
                            
                            if (ret == pdPASS) {
                                printf("Successfully created DALI worker task.\n");
                            } else {
                                printf("Failed to create DALI worker task (Out of memory).\n");
                            }
                        }else{
                            printf("DALI worker task is already running.\n");
                            vTaskDelete(dali_group_worker_task_handle);
                            dali_group_worker_task_handle = NULL; // Reset handle pointer immediately
                        }
                    }else{
                        if(dali_group_worker_task_handle == NULL){
                            BaseType_t ret2 = xTaskCreate(
                                dali_group_state_worker_task,     // Task function
                                "dali_worker_g",             // Text name for debugging
                                4096,                      // Stack size in words
                                (void*)(uint32_t)group_id,   // Pass dali_id as parameter
                                15,                         // Task priority
                                &dali_group_worker_task_handle   // Save the handle
                            );
                            
                            if (ret2 == pdPASS) {
                                printf("Successfully created DALI worker task.\n");
                            } else {
                                printf("Failed to create DALI worker task (Out of memory).\n");
                            }
                        }else{
                            printf("DALI worker task is already running.\n");
                            vTaskDelete(dali_worker_task_handle);
                            dali_worker_task_handle = NULL; // Reset handle pointer immediately
                        } 
                    } 
                } 
                else if (dali_state == 0) {
                    
                    // If the task exists, kill it cleanly
                    if (dali_worker_task_handle != NULL) {
                        vTaskDelete(dali_worker_task_handle);
                        dali_worker_task_handle = NULL; // Reset handle pointer immediately
                        
                        printf("DALI worker task deleted successfully.\n");

                        nuos_dali_set_state(dali_id, false);
                    }else if (dali_group_worker_task_handle != NULL) {
                        vTaskDelete(dali_group_worker_task_handle);
                        dali_group_worker_task_handle = NULL; // Reset handle pointer immediately
                        
                        printf("DALI group worker task deleted successfully.\n");
                        nuos_dali_set_state_group(group_id, false);
                    } else {
                        printf("Delete requested, but no active DALI task was running.\n");
                    }
                    
                }
                break;

            case 305:  //Color Mode
                sdali_id= cJSON_GetObjectItem(root, "dali_id");
                if (sdali_id == NULL) {
                    printf("Missing JSON keys sdali_id\n");
                    cJSON_Delete(root);
                    return;
                }     
                dali_id = sdali_id->valueint;
                printf("dali_id: %d\n", dali_id);

                cJSON* smode = cJSON_GetObjectItem(root, "mode");
                if (smode == NULL) {
                    printf("Missing JSON keys mode\n");
                    cJSON_Delete(root);
                    return;
                }     
                printf("smode: %d\n", smode->valueint);
                uint8_t mode = smode->valueint;
                uint16_t val = 0;
                uint8_t r = 0,g = 0,b = 0;
                cJSON* sval = cJSON_GetObjectItem(root, "val");
                if (sval == NULL) {
                    //printf("Missing JSON keys val\n");
                    //cJSON_Delete(root);
                    cJSON* sR = cJSON_GetObjectItem(root, "r");
                    if (sR == NULL) {
                        cJSON_Delete(root);
                        return;
                    }
                    cJSON* sG = cJSON_GetObjectItem(root, "g");
                    if (sG == NULL) {
                        cJSON_Delete(root);
                        return;
                    }
                    cJSON* sB = cJSON_GetObjectItem(root, "b");
                    if (sB == NULL) {
                        cJSON_Delete(root);
                        return;
                    }
                    r = sR->valueint;
                    g = sG->valueint;
                    b = sB->valueint;

                }else{
                    printf("sval: %d\n", sval->valueint);
                    val = sval->valueint;
                }     


                nuos_prepare_color_mode(mode);
                if(mode == 0) 
                    nuos_dali_set_cct_color(dali_id, val);
                else if(mode == 1) {
                    if(r==0xff) r = 0xfe;
                    if(g==0xff) g = 0xfe;
                    if(b==0xff) b = 0xfe;

                    nuos_dali_set_rgb_color(dali_id, r,g,b, true);
                }
                break;
            #endif
            case 11:  //Toggle DALI Group
                sindex = cJSON_GetObjectItem(root, "index");
                if (sindex == NULL) {
                    printf("Missing JSON keys index\n");
                    cJSON_Delete(root);
                    return;
                }     
                // printf("sindex: %d\n", sindex->valueint);
                index = sindex->valueint;
                if(dali_nvs_stt[index].state == 0) dali_nvs_stt[index].state = 1;
                else dali_nvs_stt[index].state = 0;
                nuos_dali_toggle_group(dali_nvs_stt[index].group_id, index, dali_nvs_stt[index].state, dali_nvs_stt[index].brightness);
                nuos_store_dali_data_to_nvs(index);
                break;
                
            case 17:  //Set Intensity of DALI Group
                sindex = cJSON_GetObjectItem(root, "index");
                if (sindex == NULL) {
                    printf("Missing JSON keys index\n");
                    cJSON_Delete(root);
                    return;
                }   
                index = sindex->valueint;  
                // printf("sindex: %d\n", index);
                cJSON *svalue = cJSON_GetObjectItem(root, "value");
                if (svalue == NULL) {
                    printf("Missing JSON keys sinput\n");
                    cJSON_Delete(root);
                    return;
                }
                uint8_t brightness =  svalue->valueint;
                printf("svalue: %d\n", svalue->valueint);

                
                dali_nvs_stt[index].brightness = (uint8_t)map(brightness, 0, 100, 0, 254);
                nuos_dali_set_group_brightness(dali_nvs_stt[index].group_id, index, dali_nvs_stt[index].brightness);
                nuos_store_dali_data_to_nvs(index);

                break;
        #endif
        #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
            case 16:  //Set Color Temperature of DALI Group
                sindex = cJSON_GetObjectItem(root, "index");
                if (sindex == NULL) {
                    printf("Missing JSON keys index\n");
                    cJSON_Delete(root);
                    return;
                }     
                index = sindex->valueint;
                // printf("sindex: %d\n", index);
                svalue = cJSON_GetObjectItem(root, "value");
                if (svalue == NULL) {
                    printf("Missing JSON keys sinput\n");
                    cJSON_Delete(root);
                    return;
                }
                //printf("svalue: %d\n", svalue->valueint);
                dali_nvs_stt[index].color_value = (uint16_t)svalue->valueint;
                nuos_dali_set_group_color_temperature(dali_nvs_stt[index].group_id, index, dali_nvs_stt[index].color_value);
                nuos_store_dali_data_to_nvs(index);
                break;
        #endif
        #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI)// || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
            case 12:  //Set Intensity of DALI Group
                //{fxn: 12, start_addr: 0, max_addr: 15}
                int max_address = 0;
                sindex = cJSON_GetObjectItem(root, "max_addr");
                if (sindex == NULL) {
                    printf("Missing JSON keys max_addr\n");
                    //cJSON_Delete(root);
                    //return;
                } else{ 
                    max_address = sindex->valueint;
                }
                int start_address = 0;

                cJSON *sstartAddr = cJSON_GetObjectItem(root, "start_addr");
                if (sstartAddr == NULL) {
                    printf("Missing JSON keys start_addr\n");
                    //cJSON_Delete(root);
                    start_address = 0;
                }else{
                    start_address = sstartAddr->valueint;
                }

                esp_stop_timer();
                
                setNVSDaliNodesCommissioningCounts(max_address);
                
                int total_commissioned = start_dali_addressing(start_address, max_address);

                cJSON *root_o = cJSON_CreateArray();
                cJSON *item = cJSON_CreateObject();
                if (item == NULL) {
                    ESP_LOGE(TAG, "Failed to allocate memory for JSON Object");
                    //cJSON_Delete(root); 
                    // response = "[{\"error\":\"JSON memory allocation failed!!\"}]";
                    // return response;
                }
                cJSON_AddNumberToObject(item, "total", total_commissioned);

                cJSON_AddItemToArray(root_o, item);

                const char* response = cJSON_PrintUnformatted(root_o);
                printf("%s\n", response);
                cJSON_Delete(root_o); 
                break;
        #endif

case 40:

           // {"fxn":"40","scene_ids":[1],"control_type":1}

           #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
            cJSON *sscnid = cJSON_GetObjectItem(root, "scene_ids");
            if (sscnid == NULL) {
                printf("Missing JSON keys scene_ids\n");
                cJSON_Delete(root);                
                return;
            }
            // scene_group_switch_info.group_id = cJSON_GetObjectItem(root, "group_id")->valueint;
            for (int i = 0; i < cJSON_GetArraySize(sscnid); ++i) {
                scene_group_switch_info.scene_ids[i] = cJSON_GetArrayItem(sscnid, i)->valueint;
            }

            cJSON *sctrltype = cJSON_GetObjectItem(root, "control_type");
            if (sctrltype == NULL) {
                printf("Missing JSON keys control_type\n");
                cJSON_Delete(root);                
                return;
            }

            scene_group_switch_info.control_type = sctrltype->valueint;
            cJSON *sscnctrltype = cJSON_GetObjectItem(root, "scn_ctrl_type");
            if (sscnctrltype == NULL) {
                printf("Missing JSON keys scn_ctrl_type\n");
                //cJSON_Delete(root);                
                //return;
            } else {           
                scene_group_switch_info.scn_ctrl_type = sscnctrltype->valueint;
            }
            // switch_driver_gpios_intr_enabled(false);
            // dali_rx_intr_enabled(false);
            nuos_store_dali_scene_switch_data_to_nvs(&scene_group_switch_info);
            // dali_rx_intr_enabled(true);
            // switch_driver_gpios_intr_enabled(true);
            #endif
        break;

        case 42:
            //{fxn: "42", index: 1, id: "scene2"}
            cJSON * sindex6 = cJSON_GetObjectItem(root, "index");
            if (sindex6 == NULL) {
                printf("Missing JSON keys index\n");
                cJSON_Delete(root);
                return;
            }  
            
            #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH )
            int index33 = sindex6->valueint;
            if(scene_group_switch_info.control_type == 1){
                process_dali_tasks(index33, false, false);
            }else{
                process_dali_tasks(index33, true, false);
            }
            #endif
        break;

        case 38:
            //{"fxn":38,"input_id":0,"group_id":10,"selected_ids":[1,2,3,4]}
            #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
            cJSON * sindex22 = cJSON_GetObjectItem(root, "input_id");
            cJSON *ids = cJSON_GetObjectItem(root, "selected_ids");
            cJSON *group = cJSON_GetObjectItem(root, "group_id");

            if (sindex22 == NULL) {
                printf("Missing JSON keys index\n");
                cJSON_Delete(root);
                return;
            } 

            int index22 = sindex22->valueint;
            //printf("sindex: %d\n", index);
            int gid = 0;
            if (group && cJSON_IsString(group)) {
                gid = atoi(group->valuestring);
            }else{
                gid = group->valueint;
            }
            printf("gid: %d\n", gid);
            if (gid < 0 || gid >= GROUP_COUNT) {
                ESP_LOGW(TAG, "fxn201: group_id out of range %d", gid);
                gid = 255;
            }

            
            
            // Get the values array
            if (!cJSON_IsArray(ids))
            {
                ESP_LOGE(TAG, "Values is not an array");
                cJSON_Delete(root);
                return;
            }
            printf("index22:%d gid:%d\n", index22, gid);
            //scene_group_switch_info.scene_ids[index22] = gid;
            scene_group_switch_info.group_id[index22] = gid;
            // Iterate over the array and print the values
            int arraySize1 = cJSON_GetArraySize(ids);      
            int jj = 0;  // Remove invalids
            for (int i = 0; i < arraySize1; ++i)
            {
                cJSON *item1 = cJSON_GetArrayItem(ids, i);
                if (cJSON_IsNumber(item1))
                {
                    int value = item1->valueint;
                    temp_result[i] = value;
                    if (temp_result[i] != DALI_INVALID_ADDRESS) {
                        final_result[jj++] = temp_result[i];
                    }
                    ESP_LOGI(TAG, "Value at index %d: %d", i, temp_result[i]);
                    
                }
            }
            final_result_size = jj;
            //////// <--
            // Remove duplicates
            jj=0;
            for (int i = 0; i < final_result_size; ++i) {
                bool is_duplicate = false;
                for (int k = 0; k < jj; ++k) {
                    if (scene_group_switch_info.device_ids[index22][k] == final_result[i]) {
                        is_duplicate = true;
                        break;
                    }
                }
                if (!is_duplicate) {
                    scene_group_switch_info.device_ids[index22][jj++] = final_result[i];
                }
            }

            scene_group_switch_info.total_ids[index22] = jj;
            printf("total_ids:%d\n", scene_group_switch_info.total_ids[index22]);
            // Print the final result array
            printf("Array without zeros and duplicates: ");
            for (int i = 0; i < scene_group_switch_info.total_ids[index22]; ++i) {
                printf("%d ", scene_group_switch_info.device_ids[index22][i]);

                nuos_dali_add_light_to_group(scene_group_switch_info.device_ids[index22][i], scene_group_switch_info.group_id[index22]);
                vTaskDelay(60 / portTICK_PERIOD_MS);

            }
            printf("\n");
            for (int p = scene_group_switch_info.total_ids[index22]; p < MAX_DALI_DEVICES_IN_SCENES; p++) {
                scene_group_switch_info.device_ids[index22][p] = DALI_INVALID_ADDRESS;
            }

            // switch_driver_gpios_intr_enabled(false);
            // dali_rx_intr_enabled(false);
            nuos_store_dali_scene_switch_data_to_nvs(&scene_group_switch_info);
            // dali_rx_intr_enabled(true);
            // switch_driver_gpios_intr_enabled(true); 
        
            #endif         
        break;

        case 39:
            #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
            sindex22 = cJSON_GetObjectItem(root, "input_id");
            ids = cJSON_GetObjectItem(root, "selected_ids");
            group = cJSON_GetObjectItem(root, "group_id");

            if (sindex22 == NULL) {
                printf("Missing JSON keys index\n");
                cJSON_Delete(root);
                return;
            } 

            index22 = sindex22->valueint;
            gid = 0;
            if (group && cJSON_IsString(group)) {
                gid = atoi(group->valuestring);
            }else{
                gid = group->valueint;
            }
            if (gid < 0 || gid >= GROUP_COUNT) {
                ESP_LOGW(TAG, "fxn201: group_id out of range %d", gid);
                gid = 255;
            } 
            
            // Get the values array
            if (!cJSON_IsArray(ids))
            {
                ESP_LOGE(TAG, "Values is not an array");
                cJSON_Delete(root);
                return;
            }

            //scene_group_switch_info.scene_ids[index22] = gid;
            scene_group_switch_info.group_id[index22] = gid;
            // Iterate over the array and print the values
            arraySize1 = cJSON_GetArraySize(ids);      
            jj = 0;  // Remove invalids
            for (int i = 0; i < arraySize1; ++i)
            {
                cJSON *item1 = cJSON_GetArrayItem(ids, i);
                if (cJSON_IsNumber(item1))
                {
                    int value = item1->valueint;
                    
                    temp_result[i] = value;
                    if (temp_result[i] != DALI_INVALID_ADDRESS) {
                        final_result[jj++] = temp_result[i];
                    }
                    ESP_LOGI(TAG, "Value at index %d: %d", i, temp_result[i]);
                    
                }
            }
            final_result_size = jj;
            //////// <--
            // Remove duplicates
            jj=0;
            for (int i = 0; i < final_result_size; ++i) {
                bool is_duplicate = false;
                for (int k = 0; k < jj; ++k) {
                    if (scene_group_switch_info.device_ids[index22][k] == final_result[i]) {
                        is_duplicate = true;
                        break;
                    }
                }
                if (!is_duplicate) {
                    scene_group_switch_info.device_ids[index22][jj++] = final_result[i];
                }
            }

            scene_group_switch_info.total_ids[index22] = jj;
            
            // Print the final result array
            printf("Array without zeros and duplicates: ");
            for (int i = 0; i < scene_group_switch_info.total_ids[index22]; ++i) {
                printf("%d ", scene_group_switch_info.device_ids[index22][i]);
                nuos_dali_remove_light_from_group(scene_group_switch_info.device_ids[index22][i], scene_group_switch_info.group_id[index22]);
                vTaskDelay(60 / portTICK_PERIOD_MS);
            }
            printf("\n");
            for (int p = scene_group_switch_info.total_ids[index22]; p < MAX_DALI_DEVICES_IN_SCENES; p++) {
                scene_group_switch_info.device_ids[index22][p] = DALI_INVALID_ADDRESS;
            }

            // switch_driver_gpios_intr_enabled(false);
            // dali_rx_intr_enabled(false);
            nuos_store_dali_scene_switch_data_to_nvs(&scene_group_switch_info);
            // dali_rx_intr_enabled(true);
            // switch_driver_gpios_intr_enabled(true);
        
            #endif         
        break;
        case 41:
            #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
            sindex22 = cJSON_GetObjectItem(root, "input_id");
            ids = cJSON_GetObjectItem(root, "selected_ids");
            group = cJSON_GetObjectItem(root, "group_id");

            if (sindex22 == NULL) {
                printf("Missing JSON keys index\n");
                cJSON_Delete(root);
                return;
            } 

            index22 = sindex22->valueint;
            //printf("sindex: %d\n", index);
            gid = 0;
            if (group && cJSON_IsString(group)) {
                gid = atoi(group->valuestring);
            }else{
                gid = group->valueint;
            }
            if (gid < 0 || gid >= GROUP_COUNT) {
                ESP_LOGW(TAG, "fxn201: group_id out of range %d", gid);
                gid = 255;
            }

            
            
            // Get the values array
            if (!cJSON_IsArray(ids))
            {
                ESP_LOGE(TAG, "Values is not an array");
                cJSON_Delete(root);
                return;
            }
            //remove 
            #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH) 

            #else
            if(scene_group_switch_info.control_type != 0){
            
                printf("Removed from group: %d the ids: ", scene_group_switch_info.group_id[index22]);
                for (int i = 0; i < scene_group_switch_info.total_ids[index22]; ++i) {
                    printf("%d ", scene_group_switch_info.device_ids[index22][i]);
                    nuos_dali_remove_light_from_group(scene_group_switch_info.device_ids[index22][i], scene_group_switch_info.scene_ids[index22]);
                    vTaskDelay(100);
                }
                printf("\n");
            
            }
            #endif

            scene_group_switch_info.group_id[index22] = gid;
            // Iterate over the array and print the values
            arraySize1 = cJSON_GetArraySize(ids);      
            jj = 0;  // Remove invalids
            for (int i = 0; i < arraySize1; ++i)
            {
                cJSON *item1 = cJSON_GetArrayItem(ids, i);
                if (cJSON_IsNumber(item1))
                {
                    int value = item1->valueint;
                    
                    temp_result[i] = value;
                    if (temp_result[i] != DALI_INVALID_ADDRESS) {
                        final_result[jj++] = temp_result[i];
                    }
                    //ESP_LOGI(TAG, "Value at index %d: %d", i, temp_result[i]);
                    
                }
            }
            final_result_size = jj;
            //////// <--
            // Remove duplicates
            jj=0;
            for (int i = 0; i < final_result_size; ++i) {
                bool is_duplicate = false;
                for (int k = 0; k < jj; ++k) {
                    if (scene_group_switch_info.device_ids[index22][k] == final_result[i]) {
                        is_duplicate = true;
                        break;
                    }
                }
                if (!is_duplicate) {
                    scene_group_switch_info.device_ids[index22][jj++] = final_result[i];
                }
            }

            scene_group_switch_info.total_ids[index22] = jj;
            
            // Print the final result array
            printf("Array without zeros and duplicates: ");
            for (int i = 0; i < scene_group_switch_info.total_ids[index22]; ++i) {
                printf("%d ", scene_group_switch_info.device_ids[index22][i]);
                
                #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH)
                #else
                    #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)

                    #else
                    printf("Added to group: %d the id: %d ctrl_type: %d\n", scene_group_switch_info.group_id[index22], scene_group_switch_info.device_ids[index22][i], scene_group_switch_info.control_type);
                    if(scene_group_switch_info.control_type != 0 ){
                    #endif
                        nuos_dali_add_light_to_group(scene_group_switch_info.device_ids[index22][i], scene_group_switch_info.group_id[index22]);
                        vTaskDelay(80 / portTICK_PERIOD_MS);
                    #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
                    #else
                    }
                    #endif
                #endif
            }
            printf("\n");
            for (int p = scene_group_switch_info.total_ids[index22]; p < MAX_DALI_DEVICES_IN_SCENES; p++) {
                scene_group_switch_info.device_ids[index22][p] = DALI_INVALID_ADDRESS;
            }

            //nuos_store_dali_scene_switch_data_to_nvs(&scene_group_switch_info);
            
            // switch_driver_gpios_intr_enabled(false);
            // dali_rx_intr_enabled(false);
            nuos_store_dali_scene_switch_data_to_nvs(&scene_group_switch_info);
            // dali_rx_intr_enabled(true);
            // switch_driver_gpios_intr_enabled(true);

        
            #endif         
        break;
        /////////////////////////////////////////////////////////////////////

        #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
        case 70:
            cJSON *smin_dim = cJSON_GetObjectItem(root, "min_dimming_offset");
            if (!smin_dim) { cJSON_Delete(root); return; }

            // apply to dimming algorithm
            dali_min_off_offset = smin_dim ? smin_dim->valueint : 0;
            dali_range_size = 254 - dali_min_off_offset;
            printf("Min dimming offset = %d\n", dali_min_off_offset);
            // store to NVS / EEPROM / variable
            setNVSDaliMinDimOffset(dali_min_off_offset);
        break;
        case 71:
            cJSON *sfade_time = cJSON_GetObjectItem(root, "fade_time");
            if (!sfade_time) { cJSON_Delete(root); return; }

            // apply to dimming algorithm
            dali_fade_time = sfade_time ? sfade_time->valueint : 0;
            printf("Fade time = %d\n", dali_fade_time);
            nuos_set_dali_fade_time(dali_fade_time);
            // store to NVS / EEPROM / variable
            setNVSDaliFadeTime(dali_fade_time);
        break;
        case 72:
            cJSON *sfade_rate = cJSON_GetObjectItem(root, "fade_rate");
            if (!sfade_rate) { cJSON_Delete(root); return; }

            // apply to dimming algorithm
            dali_fade_rate = sfade_rate ? sfade_rate->valueint : 0;
            printf("Fade rate = %d\n", dali_fade_rate);
            nuos_set_dali_fade_rate(dali_fade_rate);
            // store to NVS / EEPROM / variable
            setNVSDaliFadeRate(dali_fade_rate);
        break;

        case 301:  //toggle group id
        {
            // Immediate toggle / longpress command for a DALI address
            // payload: { fxn:53, dali_id: <int>, state: 0|1|2, group_id: <int> }
            cJSON *dali_id = cJSON_GetObjectItem(root, "dali_id");
            cJSON *g_val  = cJSON_GetObjectItem(root, "val");
            cJSON *g_id    = cJSON_GetObjectItem(root, "group_id");
            cJSON *s_id    = cJSON_GetObjectItem(root, "scene_id");
            if (!g_val) { cJSON_Delete(root); return; }
            
            int state = 0;
            int value = g_val->valueint;
            if(value == 0) state = false;
            else state = true;
            
            if (g_id) {
                int group = g_id ? g_id->valueint : 0;
                printf("Immediate toggle state:%d group:%d\n", state, group);
                //nuos_dali_set_state_group(group, state);
                if(state) nuos_dali_set_group_brightness(group, 0, 254);
                else nuos_dali_set_state_group(group, false);

                // if(state) {
                //     uint8_t val = map(value, 0, 100, 0, 255);
                //     nuos_dali_set_group_brightness(group, 0, val);
                // }
            }else{
                if (dali_id) {
                    
                    int did = dali_id ? dali_id->valueint : 0;
                    printf("Immediate toggle state:%d did:%d\n", state, did);
                    nuos_dali_set_state(did, state);
                }
            }
        }
        break;
        case 302:  //brightness control group id
        {
            // Immediate toggle / longpress command for a DALI address
            // payload: { fxn:53, dali_id: <int>, state: 0|1|2, group_id: <int> }
            cJSON *dali_id = cJSON_GetObjectItem(root, "dali_id");
            cJSON *sbright  = cJSON_GetObjectItem(root, "val");
            cJSON *g_id    = cJSON_GetObjectItem(root, "group_id");
            if (!sbright) { cJSON_Delete(root); return; }
            int level = sbright->valueint;
            if (g_id) {
                int group = g_id ? g_id->valueint : 0;
                printf("Immediate toggle level:%d group:%d\n", level, group);
                uint8_t val = map(level, 0, 100, 0, 255);
                nuos_dali_set_group_brightness(group, 0, val);
            }else{
                if (dali_id) {
                    int did = dali_id ? dali_id->valueint : 0;
                    uint8_t val = map(level, 0, 100, 0, 255);
                    printf("Immediate toggle level:%d did:%d\n", val, did);
                    nuos_dali_set_brightness(did, val);
                }              
            }
        }
        break;
        #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH)
        case 303:  //CCT control group id
        {

            // Immediate toggle / longpress command for a DALI address
            // payload: { fxn:53, dali_id: <int>, state: 0|1|2, group_id: <int> }
            cJSON *dali_id = cJSON_GetObjectItem(root, "dali_id");
            cJSON *sVal  = cJSON_GetObjectItem(root, "val");
            cJSON *g_id    = cJSON_GetObjectItem(root, "group_id");
            cJSON *sRed    = cJSON_GetObjectItem(root, "r");
            cJSON *sGreen    = cJSON_GetObjectItem(root, "g");
            cJSON *sBlue    = cJSON_GetObjectItem(root, "b");
            uint8_t error_cnt = 0;
            bool colorMode = false;
            if (!sVal) {
                //cJSON_Delete(root); 
                //return;
                colorMode = true;
                error_cnt++;
            }
            if(!sRed){
                // cJSON_Delete(root); 
                // return;
                error_cnt++;
            }
            if(error_cnt >= 2){
                cJSON_Delete(root); 
                return;               
            }
            if(!colorMode){
                int cct_val = sVal->valueint;
                if (g_id) {
                    int group = g_id ? g_id->valueint : 0;
                    printf("Immediate toggle level:%d group:%d\n", cct_val, group);
                    nuos_dali_set_group_color_temperature(group, 0, cct_val);
                }else{
                    
                    if (dali_id) {
                        int did = dali_id ? dali_id->valueint : 0;
                        printf("Immediate toggle cct:%d did:%d\n", cct_val, did);
                        nuos_dali_set_cct_color(did, cct_val);
                    } 
                }
            }else{
                int r = sRed->valueint;
                int g = sGreen->valueint;
                int b = sBlue->valueint;

                if (g_id) {
                    int group = g_id ? g_id->valueint : 0;
                    nuos_dali_set_group_rgb_temperature(group, r, g, b);
                }else{
                    if (dali_id) {
                        int did = dali_id ? dali_id->valueint : 0;
                        #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI)
                        if(r==0xff) r = 0xfe;
                        if(g==0xff) g = 0xfe;
                        if(b==0xff) b = 0xfe;
                        nuos_dali_set_rgb_color(did, r, g, b, true);
                        #endif
                    } 
                }                
            }
        }
        break;
        #endif
        case 53:
        {
            // Immediate toggle / longpress command for a DALI address
            // payload: { fxn:53, dali_id: <int>, state: 0|1|2, group_id: <int> }
            cJSON *dali_id = cJSON_GetObjectItem(root, "dali_id");
            cJSON *sstate  = cJSON_GetObjectItem(root, "state");
            cJSON *g_id    = cJSON_GetObjectItem(root, "group_id");
            if (!dali_id || !sstate) { cJSON_Delete(root); return; }
            int id = dali_id->valueint;
            int state = sstate->valueint;
            int group = g_id ? g_id->valueint : 0;

            //printf("Immediate toggle dali_id:%d state:%d group:%d\n", id, state, group);
            // Implement immediate action (toggle or select)
            // Example: if state==1 turn ON device id, if state==0 turn OFF, if state==2 treat as longpress selection
            if (state == 1) {
                // call DALI on function (example)
                nuos_dali_set_state(id, 1);
            } else if (state == 0) {
                nuos_dali_set_state(id, 0);
            } else if (state == 2) {
                // long press selection (UI only), store in temporary buffer until explicit Save (fxn 61)
                // For convenience, we can mark in RAM array `tmp_selected_ids` (create globally)
                // Example:
                tmp_selected_ids[id] = 1; // set flagged for membership
            }
        }
        break;

        case 60:
        {
            // Save Tab2 (DALI address / Tab2 values)
            // payload example: { fxn:60, selected_address: 10 }
            cJSON *sel = cJSON_GetObjectItem(root, "selected_address");
            if (!sel) { cJSON_Delete(root); return; }
            int sel_addr = sel->valueint;
            printf("Saving Tab2 selected_address=%d\n", sel_addr);

            // Persist to NVS / existing store function
            // Provide your own implementation: e.g., write_dali_selected_address_to_nvs(sel_addr);
            //nuos_store_selected_dali_address_to_nvs(sel_addr); // implement this helper

            if(sel_addr > MAX_DALI_ADDRESSES) sel_addr = MAX_DALI_ADDRESSES;
            setNVSDaliNodesCommissioningCounts(sel_addr);
            //start_dali_addressing(sel_addr);               
        } //MunishK
        break;

        case 61:
        {
            // Save Group membership or single longpress event
            // payload: { fxn:61, action: "save_group" | "single", group_id: <int>, dali_ids: [..] }
            cJSON *action = cJSON_GetObjectItem(root, "action");
            if (!action) { cJSON_Delete(root); return; }
            const char *act = action->valuestring;
            cJSON *group = cJSON_GetObjectItem(root, "group_id");
            int group_id = group ? group->valueint : 0;

            if (strcmp(act, "save_group") == 0) {
                cJSON *ids = cJSON_GetObjectItem(root, "dali_ids");
                if (!ids || !cJSON_IsArray(ids)) { cJSON_Delete(root); return; }
                // copy ids to your persistent array and store to NVS
                int total = cJSON_GetArraySize(ids);
                int idx = 0;
                for (int i = 0; i < total; i++) {
                    final_result[idx++] = cJSON_GetArrayItem(ids, i)->valueint; // reuse array
                }
                // Save to NVS: implement nuos_store_group_membership_to_nvs(group_id, final_result, idx)
                nuos_store_group_membership_to_nvs(group_id, final_result, idx);
                printf("Saved group %d membership, count=%d\n", group_id, idx);
            } else if (strcmp(act, "single") == 0) {
                // single longpress selection persisted
                cJSON *dali_id = cJSON_GetObjectItem(root, "dali_id");
                cJSON *state = cJSON_GetObjectItem(root, "state"); // 2 expected
                if (!dali_id || !state) { cJSON_Delete(root); return; }
                int id = dali_id->valueint;
                int st = state->valueint;
                // e.g., toggle in a small NVS list representing "selected for last group"
                nuos_toggle_tmp_selection(id, group_id, st); // implement helper that marks selection in RAM/NVS
            }
        }
        break;

        case 62:
        {
            // Save Scene membership (Tab4)
            // payload: { fxn:62, action:'save_scene', group_id: <int>, dali_ids: [..] }
            cJSON *ids = cJSON_GetObjectItem(root, "dali_ids");
            cJSON *g = cJSON_GetObjectItem(root, "group_id");
            int group_id = g ? g->valueint : 0;
            if (!ids || !cJSON_IsArray(ids)) { cJSON_Delete(root); return; }

            int total = cJSON_GetArraySize(ids);
            int idx = 0;
            for (int i = 0; i < total; i++) {
                final_result[idx++] = cJSON_GetArrayItem(ids, i)->valueint;
            }
            // Persist: implement nuos_store_scene_membership_to_nvs(group_id, final_result, idx)
            nuos_store_scene_membership_to_nvs(group_id, final_result, idx);
            printf("Saved scene membership for group %d count=%d\n", group_id, idx);
        }
        break;

        case 51:
        case 201: // Group add/remove via fxn in POST body
        {
            // Expected JSON: { "fxn":201, "action":"add"|"remove", "group_id": <0..15>, "dali_ids": [0,1,2,...] }
            cJSON *action = cJSON_GetObjectItem(root, "action");
            cJSON *group = cJSON_GetObjectItem(root, "group_id");
            cJSON *ids   = cJSON_GetObjectItem(root, "dali_ids");

            if (!action || !group || !ids || !cJSON_IsString(action) || !cJSON_IsArray(ids)) {
                ESP_LOGW(TAG, "fxn201: invalid payload");
                break;
            }

            int gid = 0;
            if (group && cJSON_IsString(group)) {
                gid = atoi(group->valuestring);
            }else{
                gid = group->valueint;
            }
            if (gid < 0 || gid >= GROUP_COUNT) {
                ESP_LOGW(TAG, "fxn201: group_id out of range %d", gid);
                break;
            }

            uint8_t buf[DALI_ADDR_COUNT] = {0};
            if (read_group_blob(gid, buf) != ESP_OK) {
                // initialize zero if missing
                memset(buf, 0, sizeof(buf));
            }
            const char *act = action->valuestring;

            cJSON *it = NULL;
            if (strcmp(act, "add") == 0) {
                cJSON_ArrayForEach(it, ids) {
                    if (cJSON_IsNumber(it)) {
                        int id = it->valueint;
                        if (id >= 0 && id < DALI_ADDR_COUNT) {
                            buf[id] = 1;
                            nuos_dali_add_light_to_group(id, gid);
                        }
                    }
                }
            } else if (strcmp(act, "remove") == 0) {
                cJSON_ArrayForEach(it, ids) {
                    if (cJSON_IsNumber(it)) {
                        int id = it->valueint;
                        if (id >= 0 && id < DALI_ADDR_COUNT) {
                            buf[id] = 0;
                            nuos_dali_remove_light_from_group(id, gid);
                        }
                    }
                }
            } else {
                ESP_LOGW(TAG, "fxn201: unknown action '%s'", act);
                break;
            }

            if (write_group_blob(gid, buf) != ESP_OK) {
                ESP_LOGE(TAG, "fxn201: failed to write group %d to NVS", gid);
            } else {
                ESP_LOGI(TAG, "fxn201: group %d updated (action=%s)", gid, act);
            }
        }
        break;

       
        #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH)
        case 202:
        {
            cJSON *devices  = cJSON_GetObjectItem(root, "devices");
            cJSON *action   = cJSON_GetObjectItem(root, "action");
            cJSON *scene_id = cJSON_GetObjectItem(root, "scene_id");

            int sid = (scene_id && cJSON_IsNumber(scene_id)) ? scene_id->valueint : 0;
            uint8_t scene_index = 0xff;

            for (int k = 0; k < 4; k++) {
                if (sid == scene_group_switch_info.scene_ids[k]) {
                    scene_index = k;
                    break;
                }
            }

            if (devices && cJSON_IsArray(devices)) {
                const char *act = NULL;
                if (action && cJSON_IsString(action)) {
                    act = action->valuestring;
                } else {
                    ESP_LOGW(TAG, "fxn202(devices): missing or invalid action");
                    break;
                }

                bool is_add = (strcmp(act, "add") == 0);
                bool is_remove = (strcmp(act, "remove") == 0);
                if (!is_add && !is_remove) {
                    ESP_LOGW(TAG, "fxn202(devices): unknown action '%s'", act);
                    break;
                }

                ESP_LOGI(TAG, "fxn202: received devices payload (scene_id=%d, action=%s)", sid, act);

                cJSON *dev = NULL;
                int processed = 0;

                cJSON_ArrayForEach(dev, devices) {
                    if (!cJSON_IsObject(dev)) {
                        ESP_LOGW(TAG, "fxn202(devices): skipping non-object entry");
                        continue;
                    }

                    cJSON *j_dali       = cJSON_GetObjectItem(dev, "dali_id");
                    cJSON *j_power      = cJSON_GetObjectItem(dev, "power");
                    cJSON *j_brightness = cJSON_GetObjectItem(dev, "brightness");
                    cJSON *j_cct        = cJSON_GetObjectItem(dev, "cct");
                    cJSON *j_r          = cJSON_GetObjectItem(dev, "r");
                    cJSON *j_g          = cJSON_GetObjectItem(dev, "g");
                    cJSON *j_b          = cJSON_GetObjectItem(dev, "b");

                    if (!j_dali || !cJSON_IsNumber(j_dali)) {
                        ESP_LOGW(TAG, "fxn202(devices): missing or invalid dali_id");
                        continue;
                    }

                    int did = j_dali->valueint;
                    if (did < 0 || did >= 64) {
                        ESP_LOGW(TAG, "fxn202(devices): dali_id out of range %d", did);
                        continue;
                    }

                    int power = (j_power && cJSON_IsNumber(j_power)) ? j_power->valueint : 0;
                    int brightness = (j_brightness && cJSON_IsNumber(j_brightness)) ? j_brightness->valueint : 0;
                    uint8_t brightness_1 = map(brightness, 0, 100, 0, 255);

                    if (power == 0) {
                        brightness_1 = 0;
                    }

                    int cct = (j_cct && cJSON_IsNumber(j_cct)) ? j_cct->valueint : 0;
                    int r   = (j_r   && cJSON_IsNumber(j_r))   ? j_r->valueint   : -1;
                    int g   = (j_g   && cJSON_IsNumber(j_g))   ? j_g->valueint   : -1;
                    int b   = (j_b   && cJSON_IsNumber(j_b))   ? j_b->valueint   : -1;

                    bool has_rgb = (r >= 0 && g >= 0 && b >= 0);

                    if (is_add) {
                        scene_group_switch_info.device_ids[scene_index][processed] = did;

                        if (has_rgb) {
                            ESP_LOGI(TAG, "fxn202: ADD RGB device %d to scene %d (br=%d r=%d g=%d b=%d)",
                                    did, sid, brightness_1, r, g, b);
                            // Replace this with your actual RGB scene API if available
                            nuos_dali_rgb_add_device_to_scene((uint8_t)did,
                                                            (uint8_t)sid,
                                                            brightness_1,
                                                            (uint8_t)r,
                                                            (uint8_t)g,
                                                            (uint8_t)b);
                        } else {
                            ESP_LOGI(TAG, "fxn202: ADD CCT device %d to scene %d (br=%d cct=%d)",
                                    did, sid, brightness_1, cct);

                            nuos_dali_add_device_to_scene((uint8_t)did,
                                                        (uint8_t)sid,
                                                        brightness_1,
                                                        cct);
                            vTaskDelay(pdMS_TO_TICKS(50));    

                        }
                    } else {
                        if (is_remove) {
                            ESP_LOGI(TAG, "fxn202: REMOVE device %d from scene %d", did, sid);
                            nuos_dali_remove_device_from_scene((uint8_t)did, (uint8_t)sid);
                        }
                    }

                    vTaskDelay(pdMS_TO_TICKS(20));
                    processed++;
                }

                ESP_LOGI(TAG, "fxn202(devices): processed %d device entries", processed);

                if (is_add && scene_index != 0xff && scene_index < 16) {
                    scene_group_switch_info.total_ids[scene_index] = processed;
                    nuos_store_dali_scene_switch_data_to_nvs(&scene_group_switch_info);
                }

                esp_err_t perr = persist_devices_from_cjson_array(devices, sid, act);
                if (perr != ESP_OK) {
                    ESP_LOGW(TAG, "persist_devices_from_cjson_array failed: %s", esp_err_to_name(perr));
                } else {
                    ESP_LOGI(TAG, "persist_devices_from_cjson_array success");
                    if (g_device_scene_store) free(g_device_scene_store);
                    g_device_scene_store = NULL;
                    g_device_scene_count = 0;

                    device_scene_t *tmp = NULL;
                    size_t tmp_count = 0;
                    if (load_device_scene_store(&tmp, &tmp_count) == ESP_OK && tmp_count > 0) {
                        g_device_scene_store = tmp;
                        g_device_scene_count = tmp_count;
                    }
                }
                break;
            }
        }
        break;  
        #endif      
        #endif
       
        //#if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI)
        #ifdef USE_C3_ADAPTER_UART_HW
        case 410: //{"fxn":410,"query":"fxn=15"}
            cJSON *squery = cJSON_GetObjectItem(root, "query");
            if (!cJSON_IsString(squery) || squery->valuestring == NULL)
            {
                cJSON_Delete(root);
                return;
            }

            const char * query1 = squery->valuestring;
            //printf(query1);
            const char* response1 = parse_query(query1);
            if (response1) {
                printf("%s\n", response1);
                free((void*)response1);
            } 
        break;

        case 420: //{"fxn":420,"query":"init=0"}
            squery  = cJSON_GetObjectItem(root, "query");
            if (!squery) { cJSON_Delete(root); return; }
            const char *query2 = squery->valuestring;
            const char* response2 = parse_query_2(query2); 
            if (response2) {
                printf("%s\n", response2);
                free((void*)response2);
            }
        break;

        case 430: //{"fxn":430,"query":"{"dali_id":1,"power_on_value":0,"fade_rate":12,"fade_time":2,"group":0}"}

            squery  = cJSON_GetObjectItem(root, "query");
            if (!squery) { cJSON_Delete(root); return; }
            const char *query3 = squery->valuestring;
            parse_json_3(query3);   
        break;
        //#endif
        #endif       
        default: break;
    }
    // Clean up cJSON object
    cJSON_Delete(root);
}


void parse_json_3(const char *json_str)
{
    cJSON *root = cJSON_Parse(json_str);
    if (root == NULL) {
        ESP_LOGE(TAG, "Malformed JSON received");
        return;
    }

    cJSON *dali_id_json        = cJSON_GetObjectItem(root, "dali_id");
    // cJSON *dev_name_json       = cJSON_GetObjectItem(root, "device_name");
    cJSON *power_on_value_json = cJSON_GetObjectItem(root, "power_on_value");
    cJSON *fade_rate_json      = cJSON_GetObjectItem(root, "fade_rate");
    cJSON *fade_time_json      = cJSON_GetObjectItem(root, "fade_time");
    cJSON *group_json          = cJSON_GetObjectItem(root, "group");

    dali_nvs_storage_t storage_data;
    memset(&storage_data, 0, sizeof(storage_data));
    load_dali_config_from_nvs(&storage_data);
    int i_index = 0;
    
    if (dali_id_json && power_on_value_json && fade_rate_json && fade_time_json && group_json) {
        int dali_id        = dali_id_json->valueint;
        int power_on_value = power_on_value_json->valueint;
        int fade_rate      = fade_rate_json->valueint;
        int fade_time      = fade_time_json->valueint;
        uint16_t group     = (uint16_t)group_json->valueint;
        printf("storage_data.total_nodes:%d\n", storage_data.total_nodes);     
        for (int i = 0; i < storage_data.total_nodes; i++) {
            if (storage_data.nodes[i].dali_id == dali_id) {

                i_index = i;
                break;
            }
        }
        if(power_on_value != storage_data.nodes[i_index].power_on_value){
            //nuos_dali_set_power_on_level(dali_id, power_on_value);
        }
        if(fade_time != storage_data.nodes[i_index].fade_time || fade_rate != storage_data.nodes[i_index].fade_rate){
           // nuos_dali_set_fade_time_fade_rate(dali_id, fade_time, fade_rate);
        }

        if(group != storage_data.nodes[i_index].group){
            for (int i = 0; i < 16; i++) {
                vTaskDelay(pdMS_TO_TICKS(100));
                bool gstate = (bool)((group >> i) & 0x01);
                printf("group:%d at gstate:%d\n", i, gstate);
                if (gstate) {
                    nuos_dali_add_light_to_group(dali_id, i);
                } else {
                    nuos_dali_remove_light_from_group(dali_id, i);
                }
            }
        }
        save_dali_config_to_nvs(&storage_data);
    }else{
        printf("Getting NULL!!\n");
    }

    cJSON_Delete(root);
}
// void parse_json_3(const char *json_str)
// {
//         // Parse the received JSON string
//         cJSON *root = cJSON_Parse(json_str);
//         if (root == NULL) {
//             ESP_LOGE(TAG, "Malformed JSON received");
//            // httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid JSON");
//             return;// ESP_FAIL;
//         }

//         // Retrieve fields securely
//         cJSON *dali_id_json             = cJSON_GetObjectItem(root, "dali_id");
//         cJSON *dev_name_json            = cJSON_GetObjectItem(root, "device_name");
//         cJSON *power_on_value_json      = cJSON_GetObjectItem(root, "power_on_value");
//         cJSON *fade_rate_json           = cJSON_GetObjectItem(root, "fade_rate");
//         cJSON *fade_time_json           = cJSON_GetObjectItem(root, "fade_time");
//         cJSON *group_json               = cJSON_GetObjectItem(root, "group");
        
//         // cJSON *scene_json         = cJSON_GetObjectItem(root, "scene");
//         dali_nvs_storage_t storage_data;
//         // Zero-out the entire structure array on system boot
//         memset(&storage_data, 0, sizeof(storage_data));
//         load_dali_config_from_nvs(&storage_data); 


//         if (dali_id_json && power_on_value_json && fade_rate_json && fade_time_json && group_json) {
//             int dali_id        = dali_id_json->valueint;
//             int power_on_value = power_on_value_json->valueint;
//             int fade_rate      = fade_rate_json->valueint;
//             int fade_time      = fade_time_json->valueint;
//             uint16_t group     = (uint16_t)group_json->valueint;
            
//             //int nvs_index = 255;
//             for(int i=0; i<storage_data.total_nodes; i++){
//                 if(storage_data.nodes[i].dali_id == dali_id){
//                     //nvs_index = i;
//                     strcpy(storage_data.nodes[i].device_name, dev_name_json->valuestring);
//                     save_dali_config_to_nvs(&storage_data); 
//                     break;
//                 }
//             }

//             // Server-side validation check
//             if (power_on_value >= 0 && power_on_value <= 255 &&
//                 fade_rate >= 0 && fade_rate <= 100 &&
//                 fade_time >= 0 && fade_time <= 12 &&
//                 group >= 0 && group <= 65535) {

//                 ESP_LOGI(TAG, "Updating ID %d: Power=%d, Rate=%d, Time=%d, Gp=%d", 
//                         dali_id, power_on_value, fade_rate, fade_time, group);

//                 /* 
//                 TODO: Save these variables into your local storage arrays, 
//                         NVS Flash, or deploy directly to your physical DALI bus layout.
//                 */
//                 nuos_dali_set_power_on_level(dali_id, power_on_value);
//                 nuos_dali_set_fade_time_fade_rate(dali_id, fade_time, fade_rate);

//                 for (int i = 0; i < 16; i++) {
//                     vTaskDelay(200 / portTICK_PERIOD_MS);
//                     // Check if the bit at position i is 1
//                     if ((group >> i) & 1) {
//                         //group is i
//                         nuos_dali_add_light_to_group(dali_id, i);
//                     }else{
//                         nuos_dali_remove_light_from_group(dali_id, i);
//                     }
                    
//                 }
            
//                 // Additional storage logic here...
//                 //httpd_resp_sendstr(req, "{\"status\":\"success\"}");
//             } else {
//                 ESP_LOGE(TAG, "Values dropped: Parameters are out of range bounds");
//                 //httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Parameter values out of limits");
//             }
//         } else {
//             ESP_LOGE(TAG, "Missing required JSON fields");
//            // httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Missing required JSON fields");
//         }

//     cJSON_Delete(root);
// }

char* replaceSubstring(const char* original, const char* toReplace, const char* replaceWith) {
    char* result;
    char* insertPoint;
    const char* temp;
    int lenFront, count;

    // Count the number of times the old substring occurs in the original string
    temp = original;
    for (count = 0; (temp = strstr(temp, toReplace)); ++count) {
        temp += strlen(toReplace);
    }

    // Allocate memory for the new string
    result = (char*)malloc(strlen(original) + count * (strlen(replaceWith) - strlen(toReplace)) + 1);
    if(result == NULL) {
        printf("Failed to allocate memory\n");
        return NULL;
    }

    // Replace the substring
    temp = original;
    insertPoint = result;
    while (count--) {
        lenFront = strstr(temp, toReplace) - temp;
        memcpy(insertPoint, temp, lenFront);
        insertPoint += lenFront;
        memcpy(insertPoint, replaceWith, strlen(replaceWith));
        insertPoint += strlen(replaceWith);
        temp += lenFront + strlen(toReplace);
    }
    // Copy the rest of the string
    strcpy(insertPoint, temp);
    return result;
}

void json_worker_task(void *arg) {
    
    while (1) {
        if (xQueueReceive(json_queue, &msg, portMAX_DELAY)) {
            ESP_LOGI("JSON_WORKER", "Processing JSON in worker task");
            //switch_driver_gpios_intr_enabled(false);
            parse_json(msg.json);
            //switch_driver_gpios_intr_enabled(true);
            #if( USE_NUOS_ZB_DEVICE_TYPE != DEVICE_SCENE_DALI)
            // Notify the waiting HTTP task
            if (msg.http_task != NULL) {
                xTaskNotifyGive(msg.http_task);
            }
            #endif
        }
    }
}

#ifndef USE_C3_ADAPTER_UART_HW
/* HTTP-only handlers are compiled only on builds that host the web server. */
esp_err_t submit_post_handler(httpd_req_t *req) {
    char content[MAX_HTTP_RECV_BUFFER];
    int total_len = req->content_len;
    int received = 0;
    int ret;
    //printf("total_len:%d\n", total_len);
    if (total_len >= MAX_HTTP_RECV_BUFFER) {
        // Content too large
        httpd_resp_send_500(req);
        return ESP_FAIL;
    }

    while (received < total_len) {
        ret = httpd_req_recv(req, content + received, total_len);
        if (ret <= 0) {
            if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
                httpd_resp_send_408(req);
            } else {
                httpd_resp_send_500(req);
            }
            return ESP_FAIL;
        }
        received += ret;
    }


    content[received] = '\0'; // Null-terminate the content

 
    // Find and remove all occurrences of %23
	char *pos;
	while ((pos = strstr(content, "%23")) != NULL) {
		memmove(pos, pos + 3, strlen(pos + 3) + 1);
	}
   
    ESP_LOGI("content", " : %s", content);

    
    strncpy(msg.json, content, JSON_MAX_LEN - 1);
    msg.json[JSON_MAX_LEN - 1] = '\0';
    //switch_driver_gpios_intr_enabled(false);
    //esp_stop_timer();
    //parse_json(msg.json);
    
    //switch_driver_gpios_intr_enabled(true);
    //esp_start_timer();
    // #if( USE_NUOS_ZB_DEVICE_TYPE != DEVICE_SCENE_DALI)
    // msg.http_task = xTaskGetCurrentTaskHandle();   // store the waiting task
    // #endif
    if (xQueueSend(json_queue, &msg, pdMS_TO_TICKS(100)) != pdTRUE) {
        ESP_LOGE("HTTP", "Queue full, dropping request");
        httpd_resp_send_500(req);
        return ESP_FAIL;
    }
    httpd_resp_send(req, resp1, HTTPD_RESP_USE_STRLEN);

    cb_requests_counts = 0;
    cb_response_counts = 0;
    return ESP_OK;
}


#if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)

// A mock structure representing your DALI configuration items.
// Replace this or load this array dynamically from your NVS, SPIFFS, or RAM.
typedef struct {
    int dali_id;
    int power_on_value;
    int fade_rate;
    int fade_time;
    int group;
    int scene;
} dali_config_t;


esp_err_t http_set_config_handler(httpd_req_t *req) {
    char buf[256];
    int ret, remaining = req->content_len;

    // Check if payload fits in local buffer safely
    if (remaining >= sizeof(buf)) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Payload too large");
        return ESP_FAIL;
    }

    // Read the incoming data stream
    int offset = 0;
    while (remaining > 0) {
        if ((ret = httpd_req_recv(req, buf + offset, remaining)) <= 0) {
            if (ret == HTTPD_SOCK_ERR_TIMEOUT) continue;
            return ESP_FAIL;
        }
        remaining -= ret;
        offset += ret;
    }
    buf[offset] = '\0'; // Null-terminate string

    // Parse the received JSON string
    cJSON *root = cJSON_Parse(buf);
    if (root == NULL) {
        ESP_LOGE(TAG, "Malformed JSON received");
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid JSON");
        return ESP_FAIL;
    }

    // Retrieve fields securely
    cJSON *dali_id_json       = cJSON_GetObjectItem(root, "dali_id");
    cJSON *power_on_value_json = cJSON_GetObjectItem(root, "power_on_value");
    cJSON *fade_rate_json     = cJSON_GetObjectItem(root, "fade_rate");
    cJSON *fade_time_json     = cJSON_GetObjectItem(root, "fade_time");
    cJSON *group_json         = cJSON_GetObjectItem(root, "group");
    // cJSON *scene_json         = cJSON_GetObjectItem(root, "scene");

    if (dali_id_json && power_on_value_json && fade_rate_json && fade_time_json && group_json) {
        int dali_id        = dali_id_json->valueint;
        int power_on_value = power_on_value_json->valueint;
        int fade_rate      = fade_rate_json->valueint;
        int fade_time      = fade_time_json->valueint;
        int group          = group_json->valueint;
        // int scene          = scene_json->valueint;

        // Server-side validation check
        if (power_on_value >= 0 && power_on_value <= 255 &&
            fade_rate >= 0 && fade_rate <= 100 &&
            fade_time >= 0 && fade_time <= 12 &&
            group >= 0 && group <= 65535) {

            ESP_LOGI(TAG, "Updating ID %d: Power=%d, Rate=%d, Time=%d, Gp=%d", 
                     dali_id, power_on_value, fade_rate, fade_time, group);

            /* 
               TODO: Save these variables into your local storage arrays, 
                     NVS Flash, or deploy directly to your physical DALI bus layout.
            */
            nuos_dali_set_power_on_level(dali_id, power_on_value);
            nuos_dali_set_fade_time_fade_rate(dali_id, fade_time, fade_rate);

            for (int i = 0; i < 16; i++) {
                // Check if the bit at position i is 1
                if ((group >> i) & 1) {
                    //group is i
                    nuos_dali_add_light_to_group(dali_id, i);
                }else{
                    nuos_dali_remove_light_from_group(dali_id, i);
                }
                vTaskDelay(200 / portTICK_PERIOD_MS);
            }
           
            // Additional storage logic here...
            httpd_resp_sendstr(req, "{\"status\":\"success\"}");
        } else {
            ESP_LOGE(TAG, "Values dropped: Parameters are out of range bounds");
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Parameter values out of limits");
        }
    } else {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Missing required JSON fields");
    }

    cJSON_Delete(root);
    return ESP_OK;
}

esp_err_t http_get_config_handler(httpd_req_t *req) {
    char query[128];
    char value_fxn[32];

    char *response = "[]"; // Default response if no valid query is found


    if (httpd_req_get_url_query_str(req, query, sizeof(query)) == ESP_OK) {
        ESP_LOGI(TAG, "Found URL query => %s", query);
        response = parse_query_2(query); 
    }

    httpd_resp_set_type(req, "application/json");

    // Enable CORS header if your frontend is hosted on a different port/device during development
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");

    httpd_resp_send(req, response, HTTPD_RESP_USE_STRLEN);
    free((void*)response);

    return ESP_OK;

}
    esp_err_t http_get_items_handler(httpd_req_t *req) {

        char query[128];
        // char value_fxn[32];
        // char value_data[32];
        // uint8_t scene_id = 0xff;
        // int erase_data = 0;

        char *response  = "[]";
        int index = 0;
        // Retrieve the query string from the URL
        if (httpd_req_get_url_query_str(req, query, sizeof(query)) == ESP_OK) {
            ESP_LOGI(TAG, "Found URL query => %s", query);
            // Retrieve specific query parameter value
            response = parse_query(query);
        }
        // 4. Set Content-Type to JSON so the browser fetch API understands it automatically
        httpd_resp_set_type(req, "application/json");

        // Enable CORS header if your frontend is hosted on a different port/device during development
        httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");

        httpd_resp_send(req, response, HTTPD_RESP_USE_STRLEN);
        free((void*)response);
        return ESP_OK;
    }
#endif
#endif
const char* response_error_1 = "{\"error\":\"DALI Bus Error!!\"}";
const char* response_error_2 = "{\"error\":\"JSON creation failed!!\"}";
const char* response_error_3 = "{\"error\":\"JSON memory allocation failed!!\"}";
const char* response_error_4 = "{\"error\":\"JSON printing failed\"}";
const char* response_error_5 = "{\"error\":\"JSON memory allocation failed\"}";


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

/* Compatible return codes */
#ifndef ESP_OK
#define ESP_OK 0
#endif

#ifndef ESP_FAIL
#define ESP_FAIL -1
#endif

#ifndef ESP_ERR_HTTPD_RESULT_TRUNC
#define ESP_ERR_HTTPD_RESULT_TRUNC 0x103
#endif

#ifndef ESP_ERR_NOT_FOUND
#define ESP_ERR_NOT_FOUND 0x105
#endif

/*
 * Replacement for ESP-IDF httpd_query_key_value()
 *
 * query:  Query string, e.g. "fxn=light_on&ep=1"
 * key:    Parameter name, e.g. "fxn"
 * value:  Output buffer
 * value_len: Size of output buffer
 */
int httpd_query_key_value(const char *query,
                          const char *key,
                          char *value,
                          size_t value_len)
{
    if (query == NULL || key == NULL ||
        value == NULL || value_len == 0)
    {
        return ESP_FAIL;
    }

    value[0] = '\0';

    size_t key_len = strlen(key);
    const char *p = query;

    /* Skip an optional '?' at the start */
    if (*p == '?')
    {
        p++;
    }

    while (*p != '\0')
    {
        const char *pair_end = strchr(p, '&');

        if (pair_end == NULL)
        {
            pair_end = p + strlen(p);
        }

        const char *equals = memchr(p, '=', pair_end - p);

        if (equals != NULL &&
            (size_t)(equals - p) == key_len &&
            memcmp(p, key, key_len) == 0)
        {
            const char *value_start = equals + 1;
            size_t len = (size_t)(pair_end - value_start);

            if (len >= value_len)
            {
                memcpy(value, value_start, value_len - 1);
                value[value_len - 1] = '\0';
                return ESP_ERR_HTTPD_RESULT_TRUNC;
            }

            memcpy(value, value_start, len);
            value[len] = '\0';

            return ESP_OK;
        }

        if (*pair_end == '\0')
        {
            break;
        }

        p = pair_end + 1;
    }

    return ESP_ERR_NOT_FOUND;
}

char * parse_query_2(const char *req_query) {

    char value_fxn[32];
    char value_data[32];
    uint8_t scene_id = 0xff;
    int erase_data = 0;

    char *response  = "[]";

    // Prepare storage variable
    dali_nvs_storage_t my_dali_system;
    cJSON *root = cJSON_CreateArray();
    if (root == NULL) {
        ESP_LOGE(TAG, "Failed to allocate memory for JSON Array");
        //httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "JSON creation failed");
        //return ESP_FAIL;
        //response = "{\"error\":\"JSON creation failed!!\"}";
        cJSON_Delete(root); 
        return response_error_2;
    }

    
    // Retrieve specific query parameter value
    if (httpd_query_key_value(req_query, "dali_id", value_fxn, sizeof(value_fxn)) == ESP_OK) {
       // ESP_LOGI(TAG, "Found URL query parameter => dali_id=%s", value_fxn);
        memset(&my_dali_system, 0, sizeof(my_dali_system));
        // 3. Attempt to load existing configurations
        esp_err_t err = load_dali_config_from_nvs(&my_dali_system);
        if (err == ESP_ERR_NVS_NOT_FOUND) {
            // First boot! Setup default dummy configurations
        } else if (err == ESP_OK) {
            // Successfully loaded from flash memory
            // ESP_LOGI(TAG_NVS, "Driver 0 Config -> ID: %d, PowerOn: %d", 
            //         my_dali_system.nodes[0].dali_id, 
            //         my_dali_system.nodes[0].power_on_value);      
        }


        int dali_id = atoi(value_fxn);  
        int k_index = 255;
        bool dali_id_found_flag = false;

        // Replace string literal returns with strdup so free() is safe

        for(int k=0; k<my_dali_system.total_nodes; k++){
            if(my_dali_system.nodes[k].dali_id == dali_id){
                dali_id_found_flag = true;
                k_index = k;
            }
        }
        //ventilation, opening, 
        if(!dali_id_found_flag) return response;
        //printf("Dali ID found!!\n");

        cJSON *item = cJSON_CreateObject();
        
        // 1. Create a single root JSON object
        if (item == NULL) {
            ESP_LOGE(TAG, "Failed to allocate memory for JSON Object");
            //httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "JSON memory allocation failed");
           // return ESP_FAIL;
            cJSON_Delete(root); 
           // response = "{\"error\":\"JSON memory allocation failed!!\"}";
            return response_error_3;
        }
        //printf("next_1\n");
        // 2. Add the properties directly to root_o
        cJSON_AddNumberToObject(item, "dali_id", dali_id);

        uint16_t powerOnValue = (uint8_t)(daliQueryPowerOnLevel(dali_id) & 0xff);
        //printf("DALI ID: %d, Power On Value: %d\n", dali_id, powerOnValue);
        cJSON_AddNumberToObject(item, "power_on_value", powerOnValue);
        vTaskDelay(100 / portTICK_PERIOD_MS);

        uint16_t rawResponse = daliQueryFadeTimeFadeRate(dali_id);
        vTaskDelay(100 / portTICK_PERIOD_MS);

        // Isolate the upper 4 bits (High Nibble) by shifting right by 4
        uint8_t fadeTimeRaw = (rawResponse >> 4) & 0x0F;
        // Isolate the lower 4 bits (Low Nibble) by applying the 0x0F mask directly
        uint8_t fadeRateRaw = rawResponse & 0x0F;
        cJSON_AddNumberToObject(item, "fade_rate", fadeRateRaw);
        cJSON_AddNumberToObject(item, "fade_time", fadeTimeRaw);
        //printf("DALI ID: %d, Fade Rate Value: %d, Fade Time Value: %d\n", dali_id, fadeRateRaw, fadeTimeRaw);

        // int32_t deviceType = daliQueryDeviceType(dali_id);
        // int32_t nextDeviceType = 0;
        // if(deviceType == 0xff){
        //     nextDeviceType = daliQueryNextDeviceType(dali_id);

        // }
        // int32_t query_gear = daliQueryGearFeatures(dali_id);
        //printf("DALI ID: %d, deviceType:%ld, nextDeviceType:%ld, Gear Features Query Result: %ld\n", dali_id, deviceType, nextDeviceType, query_gear);
        //if(nextDeviceType == 0){

        // char safe_name[32] = {0};
        // // Check if string is unitialized (0xFF in unwritten NVS/Flash), empty, or non-printable
        // unsigned char first_char = (unsigned char)my_dali_system.nodes[k_index].device_name[0];

        // if (first_char == 0 || first_char == 0xFF || first_char < 32 || first_char > 126) {
        //     // Default fallback name
        //     snprintf(safe_name, sizeof(safe_name), "Device %d", my_dali_system.nodes[k_index].dali_id);
        // } else {
        //     // Safely copy and guarantee null-termination
        //     //strncpy(safe_name, (char*)my_dali_system.nodes[k_index].device_name, sizeof(safe_name) - 1);
        //     //safe_name[sizeof(safe_name) - 1] = '\0';
        // }

        //cJSON_AddStringToObject(item, "device_name", safe_name);

            //QUERY GEAR FEATURES 247
            //deviceType = 0; // Default to 0 if the query fails
        // }else{
        //     cJSON_AddStringToObject(item, "device_name", "DT6");
        // }
        

        int32_t deviceGroupA = daliQueryDeviceInGroupA(dali_id);
        int32_t deviceGroupB = daliQueryDeviceInGroupB(dali_id);

        uint16_t groups_bitmask = deviceGroupB << 8 | deviceGroupA;

        cJSON_AddNumberToObject(item, "group", groups_bitmask);

        cJSON_AddItemToArray(root, item);


        // No nesting or adding items to objects is needed anymore!

        char *response_o = cJSON_PrintUnformatted(root);
        cJSON_Delete(root); // Free the JSON structures now that we have the string representation
        //printf("next_2\n");
        //printf("%s\n", response_o); // Log the JSON response for debugging
        if (response_o == NULL) {
            ESP_LOGE(TAG, "Failed to print JSON");
            //httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "JSON printing failed");
            //return ESP_FAIL;
            cJSON_Delete(root); 
           // response_o = "{\"error\":\"JSON printing failed\"}";
            return response_error_4;
        }
        //printf("next_3\n");
        if(k_index != 255){
            my_dali_system.nodes[k_index].power_on_value = powerOnValue;
            my_dali_system.nodes[k_index].fade_rate = fadeRateRaw;
            my_dali_system.nodes[k_index].fade_time = fadeTimeRaw;
            my_dali_system.nodes[k_index].group = groups_bitmask;
            // if(my_dali_system.nodes[k_index].device_name[0] == 0)
            // snprintf(my_dali_system.nodes[k_index].device_name, sizeof(my_dali_system.nodes[k_index].device_name), "Light_%d", dali_id);
     
            save_dali_config_to_nvs(&my_dali_system); 
        }
        //printf("response_o: %s\n", response_o);
        return response_o;
label0:
    DaliNodeList nodes = read_dali_addressed_nodes();
    my_dali_system.total_nodes = nodes.total;
    printf("Total Drivers = %d\n", nodes.total);

    if(nodes.total >= 64){
        // httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "DALI Bus Error!!");
        // return ESP_FAIL;
        if(root) cJSON_Delete(root);
       // response = "{\"error\":\"DALI Bus Error!!\"}";
        return response_error_1;
    }
    for (int i = 0; i < nodes.total; i++)
    {
        // (Adjust this loop to fetch from your database/NVS/SPIFFS as needed)
        cJSON *item = cJSON_CreateObject();
        if (item == NULL) {
            ESP_LOGE(TAG, "Failed to allocate memory for JSON Object");
            cJSON_Delete(root);
            //response = "{\"error\":\"JSON memory allocation failed\"}";
            return response_error_3;
            //httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "JSON memory allocation failed");
            //return ESP_FAIL;
        }

        // Match the exact keys expected by your JavaScript frontend
        cJSON_AddNumberToObject(item, "dali_id", nodes.addresses[i]);

        uint16_t powerOnValue = (uint8_t)(daliQueryPowerOnLevel(nodes.addresses[i]) & 0xff);
        printf("DALI ID: %d, Power On Value: %d\n", nodes.addresses[i], powerOnValue);
        cJSON_AddNumberToObject(item, "power_on_value", powerOnValue);
        vTaskDelay(100 / portTICK_PERIOD_MS);
        uint16_t rawResponse = daliQueryFadeTimeFadeRate(nodes.addresses[i]);
        vTaskDelay(100 / portTICK_PERIOD_MS);
        // Isolate the upper 4 bits (High Nibble) by shifting right by 4
        uint8_t fadeTimeRaw = (rawResponse >> 4) & 0x0F;
        // Isolate the lower 4 bits (Low Nibble) by applying the 0x0F mask directly
        uint8_t fadeRateRaw = rawResponse & 0x0F;
        cJSON_AddNumberToObject(item, "fade_rate", fadeRateRaw);
        cJSON_AddNumberToObject(item, "fade_time", fadeTimeRaw);
        printf("DALI ID: %d, Fade Rate Value: %d, Fade Time Value: %d\n", nodes.addresses[i], fadeRateRaw, fadeTimeRaw);

        int32_t deviceType = 0;//daliQueryDeviceType(nodes.addresses[i]);
        
        //int32_t query_gear = daliQueryGearFeatures(nodes.addresses[i]);

        //cJSON_AddStringToObject(item, "device_name", (char*)my_dali_system.nodes[i].device_name);

        int32_t deviceGroupA = daliQueryDeviceInGroupA(nodes.addresses[i]);
        int32_t deviceGroupB = daliQueryDeviceInGroupB(nodes.addresses[i]);
        uint16_t groups_bitmask = deviceGroupB << 8 | deviceGroupA;
        //printf("DALI ID: %d, Device Type: 0x%lx, Group A: 0x%lx, Group B: 0x%lx\n", nodes.addresses[i], deviceType, deviceGroupA, deviceGroupB);
        cJSON_AddNumberToObject(item, "group", groups_bitmask);
        // Append the item object to our root array
        cJSON_AddItemToArray(root, item);

        my_dali_system.nodes[i].dali_id = nodes.addresses[i];
        my_dali_system.nodes[i].power_on_value = powerOnValue;
        my_dali_system.nodes[i].fade_rate = fadeRateRaw;
        my_dali_system.nodes[i].fade_time = fadeTimeRaw;
        my_dali_system.nodes[i].group = groups_bitmask;
        // if(my_dali_system.nodes[i].device_name[0] == 0)
        // snprintf(my_dali_system.nodes[i].device_name, sizeof(my_dali_system.nodes[i].device_name), "Light_%d", nodes.addresses[i]);
        save_dali_config_to_nvs(&my_dali_system); 
    }

    
    label1:
    // 3. Print JSON to a raw string buffer
    char *response = cJSON_PrintUnformatted(root);

    //printf("JSON Response: %s\n", response); // Log the JSON response for debugging
    if (response == NULL) {
        ESP_LOGE(TAG, "Failed to print JSON");
        // httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "JSON printing failed");
        // return ESP_FAIL;
        response = "{\"error\":\"JSON printing failed\"}";
    }
    return response;

    }else if (httpd_query_key_value(req_query, "init", value_fxn, sizeof(value_fxn)) == ESP_OK) {
        // ESP_LOGI(TAG, "Found URL query parameter => dali_id=%s", value_fxn);
        // Attempt to load existing configurations
        int load_from_nvs = atoi(value_fxn);  

        if(load_from_nvs == 0) goto label0; // Skip loading from NVS and proceed to read DALI nodes
        memset(&my_dali_system, 0, sizeof(my_dali_system));
        esp_err_t err = load_dali_config_from_nvs(&my_dali_system);
        if (err == ESP_ERR_NVS_NOT_FOUND) {
            // First boot! Setup default dummy configurations
        } else if (err == ESP_OK) {
            // Successfully loaded from flash memory
            // ESP_LOGI(TAG_NVS, "Driver 0 Config -> ID: %d, PowerOn: %d", 
            //         my_dali_system.nodes[0].dali_id, 
            //         my_dali_system.nodes[0].power_on_value);     
                    
            
                    for(int m=0; m<my_dali_system.total_nodes; m++){
                            //printf("Address[%d] = %d\n", m, my_dali_system.nodes[m].dali_id);

                            //  Loop through your configuration items and add them to the array
                            // (Adjust this loop to fetch from your database/NVS/SPIFFS as needed)
                            cJSON *item = cJSON_CreateObject();
                            if (item == NULL) {
                                ESP_LOGE(TAG, "Failed to allocate memory for JSON Object");
                                cJSON_Delete(root);
                                // httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "JSON memory allocation failed");
                                //return ESP_FAIL;
                                return response;
                            }

                            // Match the exact keys expected by your JavaScript frontend
                            cJSON_AddNumberToObject(item, "dali_id", my_dali_system.nodes[m].dali_id);
                            cJSON_AddNumberToObject(item, "power_on_value", my_dali_system.nodes[m].power_on_value);

                            cJSON_AddNumberToObject(item, "fade_rate", my_dali_system.nodes[m].fade_rate);
                            cJSON_AddNumberToObject(item, "fade_time", my_dali_system.nodes[m].fade_time);
        

                            cJSON_AddStringToObject(item, "driver_type", "DT8");
                     
                            cJSON_AddNumberToObject(item, "group", my_dali_system.nodes[m].group);

                            // Append the item object to our root array
                            cJSON_AddItemToArray(root, item);

                            goto label1;

                    }
        }
    }

    return response;
}



char * parse_query(const char *req_query) {

    char value_fxn[64];
    char value_data[64];
    uint8_t scene_id = 0xff;
    int erase_data = 0;

    char *response  = "[]";

    if (httpd_query_key_value(req_query, "fxn", value_fxn, sizeof(value_fxn)) == ESP_OK) {
        ESP_LOGI(TAG, "Found URL query parameter => fxn=%s", value_fxn);

        int fxn = atoi(value_fxn);  
        if(fxn == 0){

        }else if(fxn == 1){
            if (httpd_query_key_value(req_query, "scene_id", value_data, sizeof(value_data)) == ESP_OK) {
                ESP_LOGI(TAG, "Found URL query parameter => scene_id=%s", value_data);
                uint8_t index = atoi(value_data);
                scene_id = index+1; 
                if (httpd_query_key_value(req_query, "erase_data", value_data, sizeof(value_data)) == ESP_OK) { 
                    erase_data = atoi(value_data);
                  //  response = nuos_do_task(index, scene_id, erase_data);
                }  
                
            }                
        }else if(fxn == 2){

        } else if(fxn == 10){  //read already saved dali addresses
            cJSON *json = cJSON_CreateArray();
            for (size_t i = 0; i < dali_nvs_stt[0].total_ids; i++) {
                // Start creating a cJSON object
                //if(dali_nvs_stt[0].device_ids[i] != DALI_INVALID_ADDRESS){
                    cJSON *item_json = cJSON_CreateObject();
                    // Add fields to the cJSON object
                    cJSON_AddNumberToObject(item_json, "Id", dali_nvs_stt[0].device_ids[i]);
                    cJSON_AddNumberToObject(item_json, "state", dali_nvs_stt[0].state);
                    cJSON_AddNumberToObject(item_json, "toggle", dali_nvs_stt[0].state);
                    cJSON_AddItemToArray(json, item_json);
                //}
            }                                             
            response = cJSON_Print(json);
            cJSON_Delete(json);
        }else if(fxn == 12){  // read new dali addresses


        }else if(fxn == 11){
            if (httpd_query_key_value(req_query, "id", value_data, sizeof(value_data)) == ESP_OK) {
                int id = atoi(value_data);
                if (httpd_query_key_value(req_query, "state", value_data, sizeof(value_data)) == ESP_OK) {
                    int state = atoi(value_data);
                    printf("id:%d  state:%d\n", id, state);
                    nuos_dali_set_state(id, state);
                }
            }
        }else if(fxn == 15){
            cJSON *item_json = cJSON_CreateObject();
            // Add fields to the cJSON object
            int group_ids[2]; //3 5 10,  6 9 11
            group_ids[0] = scene_group_switch_info.group_id[0];
            group_ids[1] = scene_group_switch_info.group_id[1];
            #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
            cJSON *group_ids_array = cJSON_CreateIntArray(group_ids, 1);
            #else
            cJSON *group_ids_array = cJSON_CreateIntArray(group_ids, 2);
            #endif
            /* corrected: create int array and use cJSON_CreateIntArray */
            int scene_ids[4];
            scene_ids[0] = scene_group_switch_info.scene_ids[0];
            scene_ids[1] = scene_group_switch_info.scene_ids[1];
            scene_ids[2] = scene_group_switch_info.scene_ids[2];
            scene_ids[3] = scene_group_switch_info.scene_ids[3];

            cJSON *scene_ids_array = cJSON_CreateIntArray(scene_ids, 4);
            #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
                if(scene_group_switch_info.control_type > 1){
                scene_group_switch_info.control_type = 0; 
                }
                if(scene_group_switch_info.scn_ctrl_type > 1){
                scene_group_switch_info.scn_ctrl_type = 0; 
                }  
            #elif(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH) 
                if(scene_group_switch_info.control_type > 1){
                    scene_group_switch_info.control_type = 0; 
                }
                if(scene_group_switch_info.scn_ctrl_type > 1){
                    scene_group_switch_info.scn_ctrl_type = 0; 
                } 
            #elif(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI)

                if(scene_group_switch_info.control_type > 1){
                    scene_group_switch_info.control_type = 0; 
                }
                if(scene_group_switch_info.scn_ctrl_type > 1){
                    scene_group_switch_info.scn_ctrl_type = 0; 
                } 

            #else
                if(scene_group_switch_info.control_type > 2){
                scene_group_switch_info.control_type = 0; 
                }
                if(scene_group_switch_info.scn_ctrl_type > 2){
                scene_group_switch_info.scn_ctrl_type = 0; 
                }                     
            #endif
            cJSON_AddItemToObject(item_json, "group_id", group_ids_array);
            cJSON_AddItemToObject(item_json, "scene_ids", scene_ids_array);
            cJSON_AddStringToObject(item_json, "control_type", switch_ctrl_type[scene_group_switch_info.control_type]);
            cJSON_AddStringToObject(item_json, "scn_ctrl_type", scene_ctrl_type[scene_group_switch_info.scn_ctrl_type]);
                                        
            response = cJSON_Print(item_json);
            //printf("%s\n", response);
            cJSON_Delete(item_json);
        }else if(fxn == 16){
            cJSON *item_json = cJSON_CreateArray();
            for (int i = 0; i < 4; i++) {
                cJSON *arr = cJSON_CreateArray();
                for (int j = 0; j < scene_group_switch_info.total_ids[i]; j++) {
                    //if (scene_group_switch_info.device_ids[i][j]) {
                        cJSON_AddItemToArray(arr, cJSON_CreateNumber(scene_group_switch_info.device_ids[i][j])); // 1-based button IDs
                    //}
                }
                cJSON_AddItemToArray(item_json, arr);
            }
            response = cJSON_Print(item_json);
            //printf("%s\n", response);
            cJSON_Delete(item_json);
            // if (!response) {
            //     httpd_resp_send_500(req);
            //     return response;//ESP_FAIL;
            // }                    
        }else if (fxn == 20) {
            // Return saved Tab2 selection
            cJSON *obj = cJSON_CreateObject();

            
            //int saved_addr = nuos_read_selected_dali_address_from_nvs(); // implement
            int saved_addr = getNVSDaliNodesCommissioningCounts(); // implement
            cJSON_AddNumberToObject(obj, "selected_address", saved_addr);

            int _dali_min_offset = getNVSDaliMinDimOffset(); // implement
            cJSON_AddNumberToObject(obj, "dali_min_offset", _dali_min_offset);

            int _fade_time = getNVSDaliFadeTime(); // implement
            cJSON_AddNumberToObject(obj, "fade_time", _fade_time);

            int _fade_rate = getNVSDaliFadeRate(); // implement
            cJSON_AddNumberToObject(obj, "fade_rate", _fade_rate);

            response = cJSON_Print(obj);
            cJSON_Delete(obj);
            //httpd_resp_send(req, resp, HTTPD_RESP_USE_STRLEN);
            //free((void*)response);
            

        } else if (fxn == 21) {
            // Return saved group membership for given group_id (or default group if not provided)
            // client calls: /items?fxn=21&group_id=3
            char value_group[32];
            int group_id = 0;
            if (httpd_query_key_value(req_query, "group_id", value_group, sizeof(value_group)) == ESP_OK) {
                group_id = atoi(value_group);
            }
            if (group_id < 0) group_id = 0;
            if (group_id >= GROUP_COUNT) group_id = 0;

            // Try to use high-level helper if available; otherwise read raw blob
            int ids[DALI_ADDR_COUNT];
            int ids_count = 0;
            memset(ids, 0, sizeof(ids));

            // If you have a helper: nuos_read_group_membership_from_nvs(group_id, ids, &ids_count);
            // If not, use read_group_blob(..) to read the bitmap and compute ids
            uint8_t blob[DALI_ADDR_COUNT] = {0};
            if (read_group_blob(group_id, blob) == ESP_OK) {
                printf("---> READ NVS OK\n");
                for (int i = 0; i < DALI_ADDR_COUNT; ++i) {
                    if (blob[i]) {
                        printf("---> i:%d\n", i);
                        ids[ids_count++] = i;
                    }
                }
            } else {
                printf("---> fallback: attempt to call wrapper and set ids_count appropriately\n");
                // fallback: attempt to call wrapper and set ids_count appropriately
                // nuos_read_group_membership_from_nvs(group_id, ids, &ids_count);
            }

            cJSON *obj = cJSON_CreateObject();
            cJSON_AddNumberToObject(obj, "group_id", group_id);
            cJSON *arr = cJSON_CreateIntArray(ids, ids_count);
            cJSON_AddItemToObject(obj, "selected_ids", arr);
            response = cJSON_Print(obj);
            cJSON_Delete(obj);
            //printf("%s\n", response);
            //httpd_resp_set_type(req, "application/json");
           // httpd_resp_send(req, resp, HTTPD_RESP_USE_STRLEN);
            //free((void*)response);

        } else if (fxn == 22) {
            // Return saved scenes for a given group
            // client calls: /items?fxn=22&group_id=3
            char value_group2[32];
            int group_id2 = 0;
            if (httpd_query_key_value(req_query, "group_id", value_group2, sizeof(value_group2)) == ESP_OK) {
                group_id2 = atoi(value_group2);
            }
            if (group_id2 < 0) group_id2 = 0;
            if (group_id2 >= GROUP_COUNT) group_id2 = 0;

            // Read scene blob for this group (SCENE_COUNT slots)
            uint8_t scene_blob[SCENE_COUNT] = {0};
            int scene_ids[SCENE_COUNT];
            int scene_count = 0;
            memset(scene_ids, 0, sizeof(scene_ids));

            if (read_scene_blob(group_id2, scene_blob) == ESP_OK) {
                for (int i = 0; i < SCENE_COUNT; ++i) {
                    if (scene_blob[i]) {
                        scene_ids[scene_count++] = i;
                    }
                }
            } else {
                // fallback: try wrapper if present
                // nuos_read_scene_membership_from_nvs(group_id2, scene_ids, &scene_count);
            }

            cJSON *obj2 = cJSON_CreateObject();
            cJSON_AddNumberToObject(obj2, "group_id", group_id2);
            cJSON *sarr = cJSON_CreateIntArray(scene_ids, scene_count);
            cJSON_AddItemToObject(obj2, "selected_scenes", sarr);
            response = cJSON_Print(obj2);
            cJSON_Delete(obj2);

            //free((void*)response);
        }
                        
    } else {
        //ESP_LOGW(TAG, "URL query parameter %s not found", key);
       // return ESP_FAIL;
    }
    return response;

}



// #endif /* !USE_C3_ADAPTER_UART_HW: HTTP-only handlers */

#ifndef USE_C3_ADAPTER_UART_HW

// Modify your http_get_handler to serve the embedded HTML
esp_err_t http_get_handler(httpd_req_t *req) {
    // Add these external declarations for the embedded HTML
    #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH)
    extern const char index_html_start[] asm("_binary_index_dali_direct_addr_html_start");
    extern const char index_html_end[]   asm("_binary_index_dali_direct_addr_html_end");
    #elif(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI)
    extern const char index_html_start[] asm("_binary_index_dali_master_fallback64_html_start");
    extern const char index_html_end[]   asm("_binary_index_dali_master_fallback64_html_end");
    #elif(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM  || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
    extern const char index_html_start[] asm("_binary_index_dali_switch_html_start");
    extern const char index_html_end[]   asm("_binary_index_dali_switch_html_end");
    #endif

    // Calculate HTML size from embedded binary
    size_t html_size = index_html_end - index_html_start;
    
    // Set proper UTF-8 headers
    //httpd_resp_set_type(req, "text/html; charset=utf-8");
    // httpd_resp_set_hdr(req, "Content-Type", "text/html; charset=utf-8");
    return httpd_resp_send(req,  (const char*)index_html_start, html_size);
}
static httpd_handle_t server = NULL;
void start_webserver() {
    #ifndef USE_C3_ADAPTER_UART_HW
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.stack_size = 8192;  // Increase the stack size
    // config.lru_purge_enable = true;   // purge least recently used sessions
    // config.send_wait_timeout = 2;     // seconds to wait for send completion (default is unlimited)
    
    httpd_uri_t index_uri = {
        .uri       = "/",
        .method    = HTTP_GET,
        .handler   = http_get_handler,
        .user_ctx  = NULL
    };

    httpd_uri_t submit_uri = {
        .uri       = "/action",
        .method    = HTTP_POST,
        .handler   = submit_post_handler,
        .user_ctx  = NULL
    };
    #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
        httpd_uri_t items_uri = {
            .uri       = "/items",
            .method    = HTTP_GET,
            .handler   = http_get_items_handler,
            .user_ctx  = NULL
        };

        #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI)
        httpd_uri_t get_config = {
            .uri       = "/get-config",
            .method    = HTTP_GET,
            .handler   = http_get_config_handler,
            .user_ctx  = NULL
        };
        httpd_uri_t set_config = {
            .uri       = "/set-config",
            .method    = HTTP_POST,
            .handler   = http_set_config_handler,
            .user_ctx  = NULL
        };
        #endif
    #endif

    esp_err_t ret = httpd_start(&server, &config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG,
                 "httpd_start failed: %s",
                 esp_err_to_name(ret));
        server = NULL;
        return;
    } 

    httpd_register_uri_handler(server, &index_uri);
    httpd_register_uri_handler(server, &submit_uri);
    #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_DALI_DIRECT_SWITCH || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_CCT_DALI_CUSTOM || USE_NUOS_ZB_DEVICE_TYPE == DEVICE_RGB_DALI)
        httpd_register_uri_handler(server, &items_uri);
        #if(USE_NUOS_ZB_DEVICE_TYPE == DEVICE_SCENE_DALI)
            httpd_register_uri_handler(server, &get_config);
            httpd_register_uri_handler(server, &set_config);
        #endif
    #endif
    #endif
    ESP_LOGI(TAG, "HTTP server started successfully");
}
#endif /* !USE_C3_ADAPTER_UART_HW: local HTTP server */

void remove_duplicates(int* array, int size, int* result, int* result_size) {
    int j = 0;
    for (int i = 0; i < size; ++i) {
        bool is_duplicate = false;
        for (int k = 0; k < j; ++k) {
            if (result[k] == array[i]) {
                is_duplicate = true;
                break;
            }
        }
        if (!is_duplicate) {
            result[j++] = array[i];
        }
    }
    *result_size = j;
}


bool nuos_init_webserver(){
    #ifdef USE_WIFI_WEBSERVER
        printf("Starting Webserver...\n");
        json_queue = xQueueCreate(JSON_QUEUE_SIZE, sizeof(json_msg_t));
        if ( json_queue == 0) {
            ESP_LOGE(TAG, "json_queue Queue was not created and must not be used");
        }    
        xTaskCreate(json_worker_task, "json_worker_task", 16384, NULL, TASK_PRIORITY_WEBSERVER, NULL);
        
        #ifdef USE_C3_ADAPTER_UART_HW

        #else

        wifi_station_main();

        start_webserver(); 
        #endif 
    #endif
    return true;
}
#endif


